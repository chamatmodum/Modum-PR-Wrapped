export interface PRMilestone {
  id: number;
  headline: string;
  metricValue: string;
  metricLabel: string;
  description: string;
  category?: string;
  quoteOrSource?: string;
  image?: string; // Optional reference image (press clipping, photo, event, award)
  stickerBadge?: string; // e.g. "RECORD", "PORTADA", "TRENDING #1", "TOP IMPACTO"
}

export type AnimationStyle = 'directional' | 'zoom' | 'smooth';

export type FontSizeScale = 'compact' | 'normal' | 'large';

export type DesignTheme =
  | 'kinetic-pop'      // Spotify Wrapped Kinetic: High-energy, bold stickers, dynamic contrasts
  | 'editorial-press'  // Editorial Luxe: Vogue / Forbes magazine vibe, refined serif & clean layout
  | 'neon-billboard';  // Dark Neon Billboard: Deep obsidian night vibe with electric berry & cyan glow

export interface ClientAccount {
  clientName: string;
  clientIndustry: string;
  clientLogo: string; // SVG or data URL
  contrastColor: string; // Hex color for vibrant contrast
  year: string;
  accountLead?: string;
  animationStyle?: AnimationStyle; // Directional kinetic text, zoom punch, or smooth editorial
  designTheme?: DesignTheme; // Visual aesthetic of the wrapped pieces
  fontSize?: FontSizeScale; // Configurable typography scale in editor
  milestones: PRMilestone[];
}

export interface ExportProgress {
  status: 'idle' | 'preparing' | 'recording' | 'processing' | 'done' | 'error';
  progress: number;
  message: string;
  videoUrl?: string;
}
