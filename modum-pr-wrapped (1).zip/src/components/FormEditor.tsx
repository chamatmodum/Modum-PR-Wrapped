import React, { useState, useEffect } from 'react';
import {
  Upload,
  Sparkles,
  Check,
  Building2,
  Trophy,
  Eye,
  Plus,
  Trash2,
  ArrowRight,
  ImageIcon,
  X,
  List,
  Layers,
  Pipette,
  Tag,
  Type
} from 'lucide-react';
import { ClientAccount, PRMilestone, AnimationStyle, DesignTheme, FontSizeScale } from '../types';
import { COLOR_SWATCHES, CLIENT_PRESETS, SAMPLE_LOGOS, SAMPLE_MILESTONE_IMAGES } from '../data/presets';

interface FormEditorProps {
  account: ClientAccount;
  onChange: (updated: ClientAccount) => void;
  onPreview: () => void;
  onLoadPreset: (presetIndex: number) => void;
}

const DESIGN_THEMES_CONFIG: {
  id: DesignTheme;
  title: string;
  subtitle: string;
  previewClass: string;
  darkText?: boolean;
}[] = [
  {
    id: 'kinetic-pop',
    title: 'Spotify Wrapped',
    subtitle: 'Vibrante, stickers y alta energía',
    previewClass: 'bg-gradient-to-br from-white via-pink-50/70 to-slate-100 border-pink-200'
  },
  {
    id: 'editorial-press',
    title: 'Editorial Forbes',
    subtitle: 'Revista de lujo y tipografía serif',
    previewClass: 'bg-gradient-to-br from-[#fdfbf7] via-amber-50/40 to-[#f5efe2] border-amber-200'
  },
  {
    id: 'neon-billboard',
    title: 'Billboard Neón',
    subtitle: 'Fondo oscuro con brillo neón',
    previewClass: 'bg-gradient-to-br from-slate-900 via-[#0a111a] to-black border-cyan-800/70',
    darkText: true
  }
];

const ANIMATION_STYLES: { id: AnimationStyle; title: string; hint: string }[] = [
  { id: 'directional', title: 'Cinética', hint: 'Entradas desde varios lados' },
  { id: 'zoom', title: 'Zoom Punch', hint: 'Métricas con impacto' },
  { id: 'smooth', title: 'Editorial', hint: 'Fundidos suaves' }
];

const SUGGESTED_STICKERS = [
  'PORTADA DEL AÑO',
  'RÉCORD HISTÓRICO',
  'TRENDING #1',
  'TOP IMPACTO',
  'ALIANZA PAÍS'
];

function isValidHex6(val: string): boolean {
  return /^#[0-9A-Fa-f]{6}$/.test(val);
}

export const FormEditor: React.FC<FormEditorProps> = ({
  account,
  onChange,
  onPreview,
  onLoadPreset
}) => {
  const [activeMilestoneTab, setActiveMilestoneTab] = useState<number>(0);
  const [milestoneViewMode, setMilestoneViewMode] = useState<'single' | 'list'>('single');
  const [hexInput, setHexInput] = useState<string>(account.contrastColor || '#00f59b');

  useEffect(() => {
    setHexInput(account.contrastColor || '#00f59b');
  }, [account.contrastColor]);

  const handleUpdateField = <K extends keyof ClientAccount>(key: K, value: ClientAccount[K]) => {
    onChange({
      ...account,
      [key]: value
    });
  };

  const handleHexInputChange = (raw: string) => {
    let formatted = raw.trim();
    if (formatted && !formatted.startsWith('#')) {
      formatted = `#${formatted}`;
    }
    setHexInput(formatted);
    if (isValidHex6(formatted)) {
      handleUpdateField('contrastColor', formatted.toLowerCase());
    }
  };

  const handleHexInputBlur = () => {
    // Expand 3-char hex like #f0a -> #ff00aa on blur if valid
    if (/^#[0-9A-Fa-f]{3}$/.test(hexInput)) {
      const r = hexInput[1];
      const g = hexInput[2];
      const b = hexInput[3];
      const expanded = `#${r}${r}${g}${g}${b}${b}`.toLowerCase();
      setHexInput(expanded);
      handleUpdateField('contrastColor', expanded);
    } else if (!isValidHex6(hexInput)) {
      setHexInput(account.contrastColor);
    }
  };

  const handleUpdateMilestone = (index: number, updatedMilestone: Partial<PRMilestone>) => {
    const newMilestones = [...account.milestones];
    newMilestones[index] = {
      ...newMilestones[index],
      ...updatedMilestone
    };
    onChange({
      ...account,
      milestones: newMilestones
    });
  };

  const handleAddMilestone = () => {
    if (account.milestones.length >= 7) return;
    const newId = account.milestones.length + 1;
    const nextMilestones = [
      ...account.milestones,
      {
        id: newId,
        metricValue: '+100%',
        metricLabel: 'Impacto alcanzado',
        stickerBadge: 'NUEVO HITO',
        headline: 'Nuevo Hito Estratégico',
        description: 'Describe brevemente el logro alcanzado este año...'
      }
    ];
    onChange({
      ...account,
      milestones: nextMilestones
    });
    setActiveMilestoneTab(nextMilestones.length - 1);
  };

  const handleRemoveMilestone = (index: number) => {
    if (account.milestones.length <= 1) return;
    const nextMilestones = account.milestones.filter((_, i) => i !== index);
    onChange({
      ...account,
      milestones: nextMilestones
    });
    setActiveMilestoneTab(Math.max(0, index - 1));
  };

  const handleSetMilestoneCount = (count: number) => {
    if (count < 1 || count > 7) return;
    let nextMilestones = [...account.milestones];
    if (count > nextMilestones.length) {
      while (nextMilestones.length < count) {
        const id = nextMilestones.length + 1;
        nextMilestones.push({
          id,
          metricValue: '+150%',
          metricLabel: 'Impacto en medios',
          stickerBadge: `HITO 0${id}`,
          headline: `Hito Estratégico 0${id}`,
          description: 'Gestión de comunicación estratégica ejecutada con éxito.'
        });
      }
    } else if (count < nextMilestones.length) {
      nextMilestones = nextMilestones.slice(0, count);
    }
    onChange({
      ...account,
      milestones: nextMilestones
    });
    if (activeMilestoneTab >= count) {
      setActiveMilestoneTab(count - 1);
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleUpdateField('clientLogo', reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMilestoneImageUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleUpdateMilestone(index, { image: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const safeIndex = Math.min(activeMilestoneTab, account.milestones.length - 1);
  const currentMilestone = account.milestones[safeIndex] || account.milestones[0];
  const rawTheme = account.designTheme as string | undefined;
  const activeDesignTheme: DesignTheme =
    rawTheme === 'editorial-press' || rawTheme === 'neon-billboard'
      ? rawTheme
      : 'kinetic-pop';

  const safeColorPickerValue = isValidHex6(account.contrastColor)
    ? account.contrastColor
    : '#00f59b';

  const renderMilestoneFields = (milestone: PRMilestone, index: number, compact = false) => (
    <div
      key={milestone.id || index}
      className={`rounded-2xl border border-slate-200/80 bg-slate-50/80 ${
        compact ? 'p-4 space-y-3' : 'p-5 space-y-4'
      }`}
    >
      {compact && (
        <div className="flex items-center justify-between border-b border-slate-200/70 pb-2">
          <span className="text-xs font-black text-[#880c59]">HITO 0{index + 1}</span>
          {account.milestones.length > 1 && (
            <button
              type="button"
              onClick={() => handleRemoveMilestone(index)}
              className="text-[11px] text-red-500 hover:text-red-700 font-semibold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              <span>Quitar</span>
            </button>
          )}
        </div>
      )}

      {/* Row 1: Cifra + Etiqueta */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
        <div className="sm:col-span-4">
          <label className="block text-[11px] font-bold text-slate-600 mb-1">
            Cifra Clave *
          </label>
          <input
            type="text"
            value={milestone.metricValue}
            onChange={(e) => handleUpdateMilestone(index, { metricValue: e.target.value })}
            placeholder="Ej: 14.5M, +320%"
            className="w-full px-3 py-2 text-base font-black font-mono bg-white border border-slate-200 rounded-xl text-[#0a3850] focus:outline-none focus:border-[#880c59]"
          />
        </div>

        <div className="sm:col-span-8">
          <label className="block text-[11px] font-bold text-slate-600 mb-1">
            Etiqueta de la Cifra *
          </label>
          <input
            type="text"
            value={milestone.metricLabel}
            onChange={(e) => handleUpdateMilestone(index, { metricLabel: e.target.value })}
            placeholder="Ej: Lectores e impactos calificados"
            className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-[#880c59]"
          />
        </div>
      </div>

      {/* Row 2: Titular */}
      <div>
        <label className="block text-[11px] font-bold text-slate-600 mb-1">
          Titular del Hito *
        </label>
        <input
          type="text"
          value={milestone.headline}
          onChange={(e) => handleUpdateMilestone(index, { headline: e.target.value })}
          placeholder="Ej: Apertura de Portada en Forbes"
          className="w-full px-3 py-2 text-sm font-bold bg-white border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-[#880c59]"
        />
      </div>

      {/* Row 3: Descripción */}
      <div>
        <label className="block text-[11px] font-bold text-slate-600 mb-1">
          Descripción Breve *
        </label>
        <textarea
          rows={compact ? 2 : 3}
          value={milestone.description}
          onChange={(e) => handleUpdateMilestone(index, { description: e.target.value })}
          placeholder="Resume qué se logró y por qué fue clave..."
          className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:border-[#880c59] resize-none"
        />
      </div>

      {/* Row 4: Compact Sticker + Optional Image Bar */}
      <div className="pt-1 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/70">
        {/* Sticker Input */}
        <div className="flex items-center gap-1.5 flex-1 min-w-[210px]">
          <Tag className="w-3.5 h-3.5 text-[#880c59] shrink-0" />
          <input
            type="text"
            value={milestone.stickerBadge || ''}
            onChange={(e) => handleUpdateMilestone(index, { stickerBadge: e.target.value })}
            placeholder="Sticker (ej: PORTADA)"
            className="w-full max-w-[180px] px-2.5 py-1 text-xs font-bold uppercase bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-[#880c59]"
          />
          {!compact && (
            <div className="hidden md:flex items-center gap-1">
              {SUGGESTED_STICKERS.slice(0, 3).map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleUpdateMilestone(index, { stickerBadge: tag })}
                  className="px-2 py-0.5 text-[10px] font-semibold rounded bg-white border border-slate-200 hover:border-[#880c59] hover:text-[#880c59] text-slate-600 transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Compact Optional Image Control */}
        <div className="flex items-center gap-2">
          {milestone.image ? (
            <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-lg border border-slate-200">
              <img
                src={milestone.image}
                alt="Ref"
                className="w-7 h-5 rounded object-cover"
              />
              <label className="text-[11px] font-bold text-[#880c59] hover:underline cursor-pointer">
                Cambiar
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleMilestoneImageUpload(index, e)}
                  className="hidden"
                />
              </label>
              <button
                type="button"
                onClick={() => handleUpdateMilestone(index, { image: undefined })}
                className="text-slate-400 hover:text-red-600"
                title="Quitar foto"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <label className="px-2.5 py-1 text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 rounded-lg cursor-pointer border border-slate-200 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-[#880c59]" />
                <span>+ Foto (opcional)</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleMilestoneImageUpload(index, e)}
                  className="hidden"
                />
              </label>
              {!compact && (
                <>
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdateMilestone(index, { image: SAMPLE_MILESTONE_IMAGES.pressTier1 })
                    }
                    className="px-2 py-1 text-[10px] font-semibold text-slate-500 hover:text-[#880c59] bg-white border border-slate-200 rounded-lg"
                  >
                    Prensa
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdateMilestone(index, { image: SAMPLE_MILESTONE_IMAGES.keynoteEvent })
                    }
                    className="px-2 py-1 text-[10px] font-semibold text-slate-500 hover:text-[#0a3850] bg-white border border-slate-200 rounded-lg"
                  >
                    Evento
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Compact Presets Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
          <Sparkles className="w-4 h-4 text-[#880c59]" />
          <span>Plantillas rápidas:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {CLIENT_PRESETS.map((preset, idx) => (
            <button
              key={preset.clientName}
              type="button"
              onClick={() => onLoadPreset(idx)}
              className="px-3 py-1 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex items-center gap-1.5"
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: preset.contrastColor }} />
              <span>{preset.clientName.split(' ')[0]}</span>
            </button>
          ))}
        </div>
      </div>

      {/* BLOQUE 1: MARCA, LOGO, COLOR HEX Y DISEÑO */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 space-y-5 shadow-xs">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
          <Building2 className="w-4 h-4 text-[#880c59]" />
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            1. Marca y Estilo
          </h3>
        </div>

        {/* Row 1: Basic Brand Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
          <div className="sm:col-span-5">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Cliente *</label>
            <input
              type="text"
              value={account.clientName}
              onChange={(e) => handleUpdateField('clientName', e.target.value)}
              placeholder="Ej: NuvoPay, Bancolombia"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:outline-none focus:border-[#880c59]"
            />
          </div>

          <div className="sm:col-span-5">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Sector *</label>
            <input
              type="text"
              value={account.clientIndustry}
              onChange={(e) => handleUpdateField('clientIndustry', e.target.value)}
              placeholder="Ej: FinTech, Retail"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:outline-none focus:border-[#880c59]"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Año</label>
            <input
              type="text"
              value={account.year}
              onChange={(e) => handleUpdateField('year', e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:bg-white focus:outline-none focus:border-[#880c59]"
            />
          </div>
        </div>

        {/* Row 2: Logo + Color de Énfasis (con Hex) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Logo del Cliente */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3.5">
            <div className="w-24 h-14 rounded-xl bg-white border border-slate-200 p-1.5 flex items-center justify-center shrink-0">
              {account.clientLogo ? (
                <img
                  src={account.clientLogo}
                  alt={account.clientName}
                  className="max-h-full max-w-full object-contain"
                />
              ) : (
                <span className="text-[10px] text-slate-400 font-bold">Sin Logo</span>
              )}
            </div>

            <div className="flex-1 min-w-0 space-y-1.5">
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-[#880c59] text-white rounded-lg cursor-pointer hover:bg-[#6e0a47] transition-colors">
                <Upload className="w-3.5 h-3.5" />
                <span>Subir Logo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <span>Ej:</span>
                <button
                  type="button"
                  onClick={() => handleUpdateField('clientLogo', SAMPLE_LOGOS.fintech)}
                  className="text-[#880c59] hover:underline font-semibold"
                >
                  NuvoPay
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => handleUpdateField('clientLogo', SAMPLE_LOGOS.retail)}
                  className="text-[#d97706] hover:underline font-semibold"
                >
                  TerraVerde
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => handleUpdateField('clientLogo', SAMPLE_LOGOS.biotech)}
                  className="text-[#0284c7] hover:underline font-semibold"
                >
                  Aura
                </button>
              </div>
            </div>
          </div>

          {/* Color de Énfasis + Hex Selector */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              Color de Énfasis (Paleta o Código Hex)
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {COLOR_SWATCHES.map((swatch) => (
                <button
                  key={swatch.hex}
                  type="button"
                  onClick={() => {
                    handleUpdateField('contrastColor', swatch.hex);
                    setHexInput(swatch.hex);
                  }}
                  title={swatch.name}
                  className={`w-6 h-6 rounded-full border-2 transition-transform flex items-center justify-center ${
                    account.contrastColor.toLowerCase() === swatch.hex.toLowerCase()
                      ? 'border-slate-900 scale-110 shadow-xs'
                      : 'border-slate-300/60 hover:scale-105'
                  }`}
                  style={{ backgroundColor: swatch.hex }}
                >
                  {account.contrastColor.toLowerCase() === swatch.hex.toLowerCase() && (
                    <Check className="w-3 h-3" style={{ color: swatch.text }} />
                  )}
                </button>
              ))}

              <div className="h-5 w-px bg-slate-200 mx-0.5" />

              {/* Native Color Picker + Hex Text Input */}
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg px-2 py-1 shadow-2xs">
                <label
                  className="relative w-5 h-5 rounded-md border border-slate-300 cursor-pointer overflow-hidden shrink-0 flex items-center justify-center"
                  style={{ backgroundColor: safeColorPickerValue }}
                  title="Elegir color personalizado"
                >
                  <Pipette className="w-3 h-3 text-white mix-blend-difference" />
                  <input
                    type="color"
                    value={safeColorPickerValue}
                    onChange={(e) => {
                      const val = e.target.value.toLowerCase();
                      setHexInput(val);
                      handleUpdateField('contrastColor', val);
                    }}
                    className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
                  />
                </label>
                <input
                  type="text"
                  value={hexInput}
                  onChange={(e) => handleHexInputChange(e.target.value)}
                  onBlur={handleHexInputBlur}
                  maxLength={7}
                  placeholder="#880c59"
                  aria-label="Código Hex de color de énfasis"
                  className="w-[70px] text-xs font-mono font-bold text-slate-800 uppercase focus:outline-none bg-transparent"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Row 3: 3 Visual Design Options + 3 Animation Pills */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-7 space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">Diseño Visual</label>
            <div className="grid grid-cols-3 gap-2">
              {DESIGN_THEMES_CONFIG.map((theme) => {
                const isSelected = activeDesignTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => handleUpdateField('designTheme', theme.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      theme.previewClass
                    } ${
                      isSelected
                        ? 'border-[#880c59] ring-2 ring-[#880c59]/30 shadow-xs'
                        : 'opacity-85 hover:opacity-100'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className={`text-xs font-black leading-tight ${
                          theme.darkText ? 'text-white' : 'text-slate-900'
                        }`}
                      >
                        {theme.title}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#880c59] shrink-0" />}
                    </div>
                    <p
                      className={`text-[10px] mt-1 leading-tight ${
                        theme.darkText ? 'text-slate-300' : 'text-slate-500'
                      }`}
                    >
                      {theme.subtitle}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="md:col-span-5 space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">Animación</label>
            <div className="grid grid-cols-3 gap-1.5 bg-slate-50 p-1.5 rounded-xl border border-slate-200/80 h-[calc(100%-22px)]">
              {ANIMATION_STYLES.map((style) => {
                const active = (account.animationStyle || 'directional') === style.id;
                return (
                  <button
                    key={style.id}
                    type="button"
                    onClick={() => handleUpdateField('animationStyle', style.id)}
                    className={`px-2 py-2 rounded-lg text-center transition-all flex flex-col justify-center ${
                      active
                        ? 'bg-white border border-[#880c59]/40 shadow-xs text-[#880c59]'
                        : 'text-slate-600 hover:bg-white/70'
                    }`}
                  >
                    <span className="text-xs font-bold leading-tight">{style.title}</span>
                    <span className="text-[10px] text-slate-400 leading-tight mt-0.5 hidden sm:block">
                      {style.hint}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Row 4: Font Size Scale Selector */}
        <div className="pt-1 flex flex-wrap items-center justify-between gap-3 bg-slate-50 border border-slate-200/80 rounded-xl px-4 py-2.5">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-[#880c59]" />
            <span className="text-xs font-bold text-slate-800">
              Tamaño de Letra en las Piezas
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-slate-200">
            {(
              [
                { id: 'compact', label: 'A  Compacto' },
                { id: 'normal', label: 'A  Normal' },
                { id: 'large', label: 'A  Grande' }
              ] as { id: FontSizeScale; label: string }[]
            ).map((opt) => {
              const active = (account.fontSize || 'normal') === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleUpdateField('fontSize', opt.id)}
                  className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                    active
                      ? 'bg-[#880c59] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* BLOQUE 2: HITOS DEL AÑO (CON VISTA POR HITO O LISTA COMPLETA) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-3 gap-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-[#880c59]" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              2. Hitos del Año
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Count Selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-500 font-medium">Cantidad:</span>
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg gap-0.5">
                {[3, 4, 5, 6, 7].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleSetMilestoneCount(num)}
                    className={`px-2 py-1 text-xs font-bold rounded-md transition-colors ${
                      account.milestones.length === num
                        ? 'bg-[#880c59] text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            {/* Single vs All List View Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg">
              <button
                type="button"
                onClick={() => setMilestoneViewMode('single')}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  milestoneViewMode === 'single'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Por Hito</span>
              </button>
              <button
                type="button"
                onClick={() => setMilestoneViewMode('list')}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  milestoneViewMode === 'list'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>Todos</span>
              </button>
            </div>
          </div>
        </div>

        {milestoneViewMode === 'single' ? (
          <>
            {/* Milestone Navigation Tabs */}
            <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
              <div className="flex items-center gap-1.5">
                {account.milestones.map((m, idx) => (
                  <button
                    key={m.id || idx}
                    type="button"
                    onClick={() => setActiveMilestoneTab(idx)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      safeIndex === idx
                        ? 'bg-[#880c59] text-white shadow-xs font-bold'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                    }`}
                  >
                    <span>0{idx + 1}</span>
                    {m.metricValue && (
                      <span className="text-[10px] opacity-80 font-mono">({m.metricValue})</span>
                    )}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {account.milestones.length < 7 && (
                  <button
                    type="button"
                    onClick={handleAddMilestone}
                    className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#880c59] bg-[#880c59]/10 hover:bg-[#880c59]/20 rounded-lg transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Agregar</span>
                  </button>
                )}
                {account.milestones.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveMilestone(safeIndex)}
                    className="p-1.5 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                    title="Eliminar este hito"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {currentMilestone && renderMilestoneFields(currentMilestone, safeIndex, false)}

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                disabled={safeIndex === 0}
                onClick={() => setActiveMilestoneTab(Math.max(0, safeIndex - 1))}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 disabled:opacity-30 font-medium"
              >
                ← Anterior
              </button>

              <button
                type="button"
                onClick={onPreview}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#880c59] bg-[#880c59]/10 hover:bg-[#880c59]/20 rounded-lg transition-colors"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Ver en Visor 9:16</span>
              </button>

              <button
                type="button"
                disabled={safeIndex >= account.milestones.length - 1}
                onClick={() =>
                  setActiveMilestoneTab(Math.min(account.milestones.length - 1, safeIndex + 1))
                }
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#880c59] hover:bg-[#6e0a47] rounded-lg disabled:opacity-30 transition-colors flex items-center gap-1"
              >
                <span>Siguiente</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </>
        ) : (
          <div className="space-y-3">
            {account.milestones.map((m, idx) => renderMilestoneFields(m, idx, true))}
            <div className="flex items-center justify-between pt-2">
              {account.milestones.length < 7 ? (
                <button
                  type="button"
                  onClick={handleAddMilestone}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-[#880c59] bg-[#880c59]/10 hover:bg-[#880c59]/20 rounded-xl transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Agregar Hito</span>
                </button>
              ) : (
                <div />
              )}
              <button
                type="button"
                onClick={onPreview}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#880c59] hover:bg-[#6e0a47] rounded-xl transition-colors"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Ver en Visor 9:16</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
