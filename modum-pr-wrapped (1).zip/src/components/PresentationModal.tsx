import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Volume2, VolumeX } from 'lucide-react';
import { ClientAccount, DesignTheme, FontSizeScale } from '../types';
import { audioSynth } from '../utils/audioSynth';
import { getContrastTextColor } from '../utils/colorContrast';
import { ModumLogo } from './ModumLogo';

interface PresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: ClientAccount;
}

export const PresentationModal: React.FC<PresentationModalProps> = ({
  isOpen,
  onClose,
  account
}) => {
  const [slide, setSlide] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(audioSynth.getMuted());
  const total = account.milestones.length + 2;

  const rawTheme = account.designTheme as string | undefined;
  const theme: DesignTheme =
    rawTheme === 'editorial-press' || rawTheme === 'neon-billboard'
      ? rawTheme
      : 'kinetic-pop';
  const fontSizeScale: FontSizeScale = account.fontSize || 'normal';

  const isNeon = theme === 'neon-billboard';
  const isEditorial = theme === 'editorial-press';
  const logoVariant = isNeon ? 'dark' : 'light';
  const accentTextColor = getContrastTextColor(account.contrastColor);

  const lightTextShadow = '[text-shadow:0_2px_10px_rgba(255,255,255,0.95),0_1px_2px_rgba(15,23,42,0.12)]';
  const darkTextShadow = '[text-shadow:0_2px_14px_rgba(0,0,0,0.92),0_1px_3px_rgba(0,0,0,0.85)]';
  const textShadowClass = isNeon ? darkTextShadow : lightTextShadow;

  const metricSizeClass =
    fontSizeScale === 'compact'
      ? 'text-5xl'
      : fontSizeScale === 'large'
      ? 'text-6xl sm:text-[4.5rem]'
      : 'text-5xl sm:text-6xl';

  const labelSizeClass =
    fontSizeScale === 'compact'
      ? 'text-[11px] sm:text-xs'
      : fontSizeScale === 'large'
      ? 'text-sm sm:text-base'
      : 'text-xs sm:text-sm';

  const headlineSizeClass =
    fontSizeScale === 'compact'
      ? 'text-lg sm:text-xl'
      : fontSizeScale === 'large'
      ? 'text-2xl sm:text-[1.7rem]'
      : 'text-xl sm:text-2xl';

  const descSizeClass =
    fontSizeScale === 'compact'
      ? 'text-xs sm:text-[13px]'
      : fontSizeScale === 'large'
      ? 'text-base sm:text-[17px]'
      : 'text-sm sm:text-[15px]';

  useEffect(() => {
    if (!isOpen) return;

    const handleKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        setSlide((s) => (s + 1) % total);
        audioSynth.playWhoosh();
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setSlide((s) => (s === 0 ? total - 1 : s - 1));
        audioSynth.playWhoosh();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose, total]);

  if (!isOpen) return null;

  const currentMilestone =
    slide >= 1 && slide <= account.milestones.length ? account.milestones[slide - 1] : null;

  const containerBg = isNeon
    ? 'bg-[#080e14] text-white border-slate-800 shadow-cyan-950/40'
    : isEditorial
    ? 'bg-[#fbfaf6] text-stone-950 border-amber-950/15'
    : 'bg-[#f8fafc] text-slate-950 border-slate-200';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-md flex flex-col items-center justify-center p-4">
      {/* Top Floating Bar: Keeps 10 Años Edition Logo */}
      <div className="absolute top-6 left-6 right-6 flex items-center justify-between text-white z-20">
        <div className="flex items-center gap-3">
          <ModumLogo variant="dark" edition="anniversary10" className="h-9 w-auto object-contain" />
          <span className="w-1.5 h-1.5 rounded-full bg-[#880c59]" />
          <span className="text-slate-200 font-semibold text-sm">
            {account.clientName} · {account.year}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const nextMute = !isMuted;
              audioSynth.setMuted(nextMute);
              setIsMuted(nextMute);
            }}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5 text-[#880c59]" />}
          </button>
          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 9:16 Slide Centered View (Standard Modum logo inside presentation) */}
      <div
        className={`relative w-full max-w-[420px] aspect-[9/16] rounded-3xl overflow-hidden border shadow-2xl flex flex-col justify-between p-7 select-none transition-colors ${containerBg}`}
      >
        {/* Glows */}
        {isNeon ? (
          <>
            <div
              className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[90px] opacity-35 pointer-events-none"
              style={{ backgroundColor: '#ff007f' }}
            />
            <div
              className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full blur-[100px] opacity-30 pointer-events-none"
              style={{ backgroundColor: account.contrastColor }}
            />
          </>
        ) : (
          <>
            <div
              className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[80px] opacity-22 pointer-events-none"
              style={{ backgroundColor: '#880c59' }}
            />
            <div
              className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full blur-[80px] opacity-22 pointer-events-none"
              style={{ backgroundColor: account.contrastColor }}
            />
          </>
        )}

        {/* Top Progress */}
        <div className="relative z-10 space-y-3">
          <div className="flex gap-1.5">
            {Array.from({ length: total }).map((_, i) => (
              <div
                key={i}
                className="flex-1 h-1.5 rounded-full transition-all"
                style={{
                  backgroundColor:
                    i < slide
                      ? isNeon
                        ? account.contrastColor
                        : '#0f172a'
                      : i === slide
                      ? isNeon
                        ? '#ff007f'
                        : '#880c59'
                      : isNeon
                      ? 'rgba(255, 255, 255, 0.18)'
                      : 'rgba(15, 23, 42, 0.18)'
                }}
              />
            ))}
          </div>
          <div className="flex items-center justify-between text-xs">
            <ModumLogo variant={logoVariant} edition="standard" className="h-6 w-auto object-contain" />
            <span className={`font-black ${isNeon ? 'text-pink-300' : 'text-[#880c59]'}`}>
              {slide === 0 ? 'INTRO' : slide === total - 1 ? 'RESUMEN' : `HITO 0${slide}`}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="relative z-10 flex-1 flex flex-col justify-center my-4 space-y-4">
          {slide === 0 && (
            <div className="space-y-4 text-center">
              <div className="flex flex-col items-center gap-1">
                <ModumLogo variant={logoVariant} edition="standard" className="h-8 w-auto object-contain" />
                <span
                  className={`text-[10px] font-black uppercase tracking-[0.25em] ${textShadowClass} ${
                    isNeon ? 'text-pink-300' : 'text-slate-700'
                  }`}
                >
                  presenta
                </span>
              </div>
              <div
                className={`font-black text-6xl sm:text-7xl tracking-tighter leading-none ${textShadowClass} ${
                  isNeon
                    ? 'text-pink-400 drop-shadow-[0_0_24px_rgba(255,0,127,0.65)] font-display'
                    : isEditorial
                    ? 'font-serif text-[#880c59] italic'
                    : 'font-display text-[#880c59]'
                }`}
              >
                {account.year}
              </div>
              <h1
                className={`font-black text-4xl sm:text-5xl tracking-tight leading-none font-display ${textShadowClass} ${
                  isNeon ? 'text-white' : 'text-slate-950'
                }`}
              >
                WRAPPED
              </h1>

              {/* Prominent Logo Card */}
              <div
                className={`p-5 rounded-3xl border shadow-lg space-y-3 ${
                  isNeon
                    ? 'bg-slate-900/95 border-slate-700'
                    : isEditorial
                    ? 'bg-white/98 border-amber-900/15'
                    : 'bg-white/98 border-slate-200'
                }`}
              >
                <div
                  className={`w-full h-24 rounded-2xl p-3 flex items-center justify-center border overflow-hidden ${
                    isNeon ? 'bg-black/90 border-slate-700' : 'bg-white border-slate-100 shadow-xs'
                  }`}
                >
                  {account.clientLogo ? (
                    <img
                      src={account.clientLogo}
                      alt={account.clientName}
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <span className="font-display font-black text-2xl text-[#0a3850]">
                      {account.clientName}
                    </span>
                  )}
                </div>
                <h3 className="font-black text-lg">{account.clientName}</h3>
                <p
                  className={`text-xs font-bold ${
                    isNeon ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  {account.clientIndustry}
                </p>
                <div
                  className={`w-full py-2 px-3 rounded-xl text-center text-xs font-black uppercase tracking-wider border ${
                    isNeon
                      ? 'bg-slate-950/90'
                      : isEditorial
                      ? 'bg-[#880c59] text-white border-[#880c59]'
                      : 'border-slate-900/15'
                  }`}
                  style={
                    isEditorial
                      ? undefined
                      : isNeon
                      ? { borderColor: account.contrastColor, color: account.contrastColor }
                      : { backgroundColor: account.contrastColor, color: accentTextColor }
                  }
                >
                  {account.milestones.length} Grandes Hitos del Año
                </div>
              </div>
            </div>
          )}

          {slide >= 1 && slide <= account.milestones.length && currentMilestone && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className={`flex items-center gap-2 ${textShadowClass}`}>
                  <span
                    className={`font-black text-2xl sm:text-3xl ${
                      isNeon ? 'text-pink-400' : isEditorial ? 'font-serif text-[#880c59]' : 'text-[#880c59]'
                    }`}
                  >
                    0{slide}
                  </span>
                  <span
                    className={`text-xs font-mono font-extrabold ${
                      isNeon ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    / 0{account.milestones.length}
                  </span>
                </div>

                <div
                  className={`px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-sm ${
                    isNeon
                      ? 'bg-pink-500/25 text-pink-200 border border-pink-400/70'
                      : isEditorial
                      ? 'bg-[#880c59] text-white'
                      : 'border border-slate-900/15'
                  }`}
                  style={
                    !isNeon && !isEditorial
                      ? { backgroundColor: account.contrastColor, color: accentTextColor }
                      : undefined
                  }
                >
                  {currentMilestone.stickerBadge || 'HITO ESTRATÉGICO'}
                </div>
              </div>

              <div
                className={`font-black ${metricSizeClass} tabular-nums leading-none tracking-tight ${textShadowClass} ${
                  isNeon
                    ? 'drop-shadow-[0_0_22px_rgba(0,229,255,0.55)]'
                    : isEditorial
                    ? 'font-serif text-[#052638]'
                    : 'text-[#052638]'
                }`}
                style={isNeon ? { color: account.contrastColor } : undefined}
              >
                {currentMilestone.metricValue}
              </div>

              <div
                className={`${labelSizeClass} font-black uppercase tracking-wider ${textShadowClass} ${
                  isNeon ? 'text-pink-300' : 'text-[#7a0a50]'
                }`}
              >
                {currentMilestone.metricLabel}
              </div>

              <div
                className="h-0.5 rounded-full"
                style={{
                  backgroundColor: isNeon
                    ? 'rgba(255,255,255,0.18)'
                    : `${account.contrastColor}`
                }}
              />

              <h3
                className={`font-black ${headlineSizeClass} leading-tight ${textShadowClass} ${
                  isEditorial ? 'font-serif' : 'font-display'
                } ${isNeon ? 'text-white' : 'text-slate-950'}`}
              >
                {isEditorial && '“'}
                {currentMilestone.headline}
                {isEditorial && '”'}
              </h3>

              {currentMilestone.image && (
                <div className="w-full h-32 rounded-2xl overflow-hidden border border-slate-300/80 shadow-xs bg-slate-100">
                  <img
                    src={currentMilestone.image}
                    alt="Evidencia del Hito"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <p
                className={`${descSizeClass} font-semibold leading-relaxed p-4 rounded-2xl border shadow-sm ${
                  isNeon
                    ? 'bg-slate-950/92 border-slate-700 text-white [text-shadow:0_1px_4px_rgba(0,0,0,0.85)]'
                    : isEditorial
                    ? 'bg-white/98 border-amber-900/15 text-stone-950'
                    : 'bg-white/98 border-slate-300/80 text-slate-950'
                }`}
              >
                {currentMilestone.description}
              </p>

              <div className="pt-1 flex items-center justify-center opacity-95">
                <ModumLogo variant={logoVariant} edition="standard" className="h-5 w-auto object-contain" />
              </div>
            </div>
          )}

          {slide === total - 1 && (
            <div className="space-y-5 text-center">
              <div className={`space-y-1.5 ${textShadowClass}`}>
                <span
                  className={`text-xs font-black uppercase tracking-widest ${
                    isNeon ? 'text-pink-300' : 'text-[#880c59]'
                  }`}
                >
                  Misión Cumplida · {account.year}
                </span>
                <h2
                  className={`font-black text-3xl sm:text-4xl leading-none ${
                    isEditorial ? 'font-serif' : 'font-display'
                  }`}
                >
                  IMPACTO IMPARABLE
                </h2>
              </div>

              <div
                className={`border p-6 rounded-3xl flex flex-col items-center gap-4 shadow-xl ${
                  isNeon
                    ? 'bg-slate-950/92 border-slate-700 text-white'
                    : isEditorial
                    ? 'bg-white/98 border-amber-900/15 text-stone-950'
                    : 'bg-white/98 border-slate-300/80 text-slate-950'
                }`}
              >
                <span
                  className={`px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-widest border ${
                    isNeon
                      ? 'bg-slate-900'
                      : isEditorial
                      ? 'bg-[#880c59] text-white border-[#880c59]'
                      : 'border-slate-900/15'
                  }`}
                  style={
                    isEditorial
                      ? undefined
                      : isNeon
                      ? { borderColor: account.contrastColor, color: account.contrastColor }
                      : { backgroundColor: account.contrastColor, color: accentTextColor }
                  }
                >
                  Edición Especial · 10 Años
                </span>

                <div className="py-2 flex items-center justify-center">
                  <ModumLogo
                    variant={logoVariant}
                    edition="anniversary10"
                    className="h-24 sm:h-28 w-auto object-contain"
                  />
                </div>

                <div
                  className="h-px w-full"
                  style={{
                    backgroundColor: isNeon ? 'rgba(255,255,255,0.14)' : 'rgba(15,23,42,0.1)'
                  }}
                />

                {account.clientLogo && (
                  <div className="flex items-center justify-center gap-2.5">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Junto a
                    </span>
                    <div
                      className={`h-8 px-3 py-1 rounded-xl border flex items-center justify-center ${
                        isNeon ? 'bg-black border-slate-700' : 'bg-white border-slate-200 shadow-2xs'
                      }`}
                    >
                      <img
                        src={account.clientLogo}
                        alt={account.clientName}
                        className="h-full object-contain max-w-[100px]"
                      />
                    </div>
                  </div>
                )}

                <p className="text-sm font-bold leading-snug">
                  Gracias por construir un año extraordinario junto a nosotros.
                </p>
                <span className={`text-xs font-black ${isNeon ? 'text-pink-300' : 'text-[#880c59]'}`}>
                  ¡Listos para superar la meta en {parseInt(account.year, 10) + 1}!
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Bottom controls */}
        <div
          className={`relative z-10 flex items-center justify-between pt-2 border-t ${
            isNeon ? 'border-slate-800' : 'border-slate-200/60'
          }`}
        >
          <button
            onClick={() => {
              setSlide((s) => (s === 0 ? total - 1 : s - 1));
              audioSynth.playWhoosh();
            }}
            className={`p-2 rounded-xl border shadow-2xs ${
              isNeon
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-xs text-slate-400 font-mono">
            {slide + 1} de {total}
          </span>
          <button
            onClick={() => {
              setSlide((s) => (s + 1) % total);
              audioSynth.playWhoosh();
            }}
            className={`p-2 rounded-xl border shadow-2xs ${
              isNeon
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
