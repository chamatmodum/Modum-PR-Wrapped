import React, { useEffect, useState } from 'react';
import { getModumLogoDataUrl, ModumLogoVariant, ModumLogoEdition } from '../utils/modumLogo';

interface ModumLogoProps {
  variant?: ModumLogoVariant;
  edition?: ModumLogoEdition;
  className?: string;
  alt?: string;
}

export const ModumLogo: React.FC<ModumLogoProps> = ({
  variant = 'light',
  edition = 'standard',
  className = 'h-7 w-auto object-contain',
  alt = 'modum estrategia + comunicación'
}) => {
  const [src, setSrc] = useState<string>('');

  useEffect(() => {
    let mounted = true;
    getModumLogoDataUrl(variant, edition).then((url) => {
      if (mounted) setSrc(url);
    });
    return () => {
      mounted = false;
    };
  }, [variant, edition]);

  if (!src) {
    const fallback =
      edition === 'anniversary10'
        ? '/assets/aistudio/Portada_ppt_general_fija-04_2d11e43f.png'
        : '/assets/aistudio/Credenciales_Modum_2026_VF.pptx_a2e0cc26.jpg';
    return (
      <img
        src={fallback}
        alt={alt}
        className={`${className} ${edition === 'standard' ? 'mix-blend-multiply' : ''}`}
      />
    );
  }

  return <img src={src} alt={alt} className={className} />;
};
