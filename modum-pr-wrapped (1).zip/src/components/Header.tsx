import React from 'react';
import { Video, Volume2, VolumeX } from 'lucide-react';
import { audioSynth } from '../utils/audioSynth';
import { ModumLogo } from './ModumLogo';

interface HeaderProps {
  activeTab: 'editor' | 'viewer' | 'export';
  setActiveTab: (tab: 'editor' | 'viewer' | 'export') => void;
  onOpenVideoExport: () => void;
  onLoadPreset: (presetIndex: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenVideoExport
}) => {
  const [isMuted, setIsMuted] = React.useState(audioSynth.getMuted());
  const [isPlayingAudio, setIsPlayingAudio] = React.useState(audioSynth.getIsPlaying());

  const handleToggleAudio = () => {
    if (!isPlayingAudio) {
      audioSynth.startBeat();
      setIsPlayingAudio(true);
      audioSynth.setMuted(false);
      setIsMuted(false);
    } else {
      const nextMute = !isMuted;
      audioSynth.setMuted(nextMute);
      setIsMuted(nextMute);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-6 py-3 shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Official modum logo */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('viewer');
          }}
          className="flex items-center gap-2.5 shrink-0 hover:opacity-85 transition-opacity"
        >
          <ModumLogo variant="light" edition="anniversary10" className="h-10 w-auto object-contain" />
          <span className="text-slate-400 text-[11px] font-bold uppercase tracking-widest border-l border-slate-200 pl-2.5">
            wrapped
          </span>
        </a>

        {/* Zone 2: Navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => setActiveTab('editor')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'editor'
                ? 'text-[#880c59] border-b-2 border-[#880c59] font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Formulario
          </button>
          <button
            onClick={() => setActiveTab('viewer')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'viewer'
                ? 'text-[#880c59] border-b-2 border-[#880c59] font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Visor 9:16
          </button>
          <button
            onClick={() => setActiveTab('export')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'export'
                ? 'text-[#880c59] border-b-2 border-[#880c59] font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Exportar Video MP4
          </button>
          <div className="h-4 w-px bg-slate-200" />
          <button
            onClick={handleToggleAudio}
            title={isPlayingAudio && !isMuted ? 'Silenciar música' : 'Activar beat synth'}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 transition-colors py-1 font-medium"
          >
            {isPlayingAudio && !isMuted ? (
              <>
                <Volume2 className="w-4 h-4 text-[#880c59] animate-pulse" />
                <span className="text-[#880c59] font-semibold">Música On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-slate-400" />
                <span>Música Off</span>
              </>
            )}
          </button>
        </nav>

        {/* Zone 3: 1 Primary CTA */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenVideoExport}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-[#880c59] to-[#0a3850] rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-[#880c59]/20 whitespace-nowrap"
          >
            <Video className="w-3.5 h-3.5" />
            <span>Descargar Video MP4</span>
          </button>
        </div>
      </div>
    </header>
  );
};
