import React, { useState } from 'react';
import {
  X,
  Video,
  Download,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Share2,
  Sparkles,
  FileArchive,
  Clock
} from 'lucide-react';
import { ClientAccount, ExportProgress } from '../types';
import { recordFullWrappedVideo, exportSlideAsPNG } from '../utils/canvasExporter';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: ClientAccount;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  account
}) => {
  const [videoProgress, setVideoProgress] = useState<ExportProgress>({
    status: 'idle',
    progress: 0,
    message: ''
  });
  const [slideDuration, setSlideDuration] = useState<number>(6.5); // Default 6.5s for comfortable reading
  const [copiedCaption, setCopiedCaption] = useState<boolean>(false);
  const [isExportingAllSlides, setIsExportingAllSlides] = useState<boolean>(false);

  if (!isOpen) return null;

  const totalSlides = account.milestones.length + 2;

  const handleStartRecording = async () => {
    try {
      setVideoProgress({
        status: 'recording',
        progress: 0,
        message: 'Preparando renderizado cinético luminoso en MP4...'
      });

      const { blob } = await recordFullWrappedVideo(
        account,
        (progress, message) => {
          setVideoProgress({
            status: 'recording',
            progress,
            message
          });
        },
        slideDuration
      );

      const videoUrl = URL.createObjectURL(blob);
      setVideoProgress({
        status: 'done',
        progress: 100,
        message: '¡Video MP4 listo para redes sociales!',
        videoUrl
      });
    } catch (err) {
      console.error('Error generating video:', err);
      setVideoProgress({
        status: 'error',
        progress: 0,
        message: 'Ocurrió un error al generar el video. Intenta nuevamente.'
      });
    }
  };

  const handleDownloadRecordedVideo = () => {
    if (!videoProgress.videoUrl) return;
    const a = document.createElement('a');
    a.href = videoProgress.videoUrl;
    a.download = `modum_wrapped_${account.clientName.replace(/\s+/g, '_')}_${account.year}.mp4`;
    a.click();
  };

  const handleDownloadAllSlides = async () => {
    try {
      setIsExportingAllSlides(true);

      for (let i = 0; i < totalSlides; i++) {
        const slideName =
          i === 0
            ? '00_Intro'
            : i === totalSlides - 1
            ? '99_Cierre'
            : `0${i}_Hito`;

        const dataUrl = await exportSlideAsPNG(account, i);
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = `modum_${account.clientName.replace(/\s+/g, '_')}_${slideName}.png`;
        a.click();
        await new Promise((r) => setTimeout(r, 250));
      }
    } catch (err) {
      console.error('Error downloading slides:', err);
    } finally {
      setIsExportingAllSlides(false);
    }
  };

  const socialCaption = `¡Un año extraordinario de impacto y liderazgo estratégico! 🚀✨\n\nJunto a @modum presentamos el #Wrapped${account.year} de ${account.clientName}. ${account.milestones.length} hitos que consolidaron nuestra posición en ${account.clientIndustry}:\n\n` +
    account.milestones
      .map((m, i) => `0${i + 1}. ${m.headline} (${m.metricValue} - ${m.metricLabel})`)
      .join('\n') +
    `\n\nGracias a todo el equipo y aliados por hacer posible este resultado.\n\n#modum #estrategia #${account.clientName.replace(/\s+/g, '')} #impacto`;

  const handleCopyCaption = () => {
    navigator.clipboard.writeText(socialCaption);
    setCopiedCaption(true);
    setTimeout(() => setCopiedCaption(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#880c59] to-[#0a3850] flex items-center justify-center text-white shadow-md shadow-[#880c59]/25">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                Exportar Video Vertical MP4 (9:16)
              </h3>
              <p className="text-xs text-slate-500">
                Formato luminoso .MP4 optimizado para Instagram Stories, TikTok, Reels y LinkedIn
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full bg-slate-100 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SECTION 1: Video Vertical Generation in MP4 */}
        <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#880c59]" />
              <h4 className="text-sm font-bold text-slate-900">1. Video Animado en Formato MP4</h4>
            </div>
            <span className="text-[11px] text-[#880c59] font-mono font-bold bg-[#880c59]/10 px-2.5 py-0.5 rounded-lg border border-[#880c59]/20">
              MP4 · 1080×1920 · 30fps · Audio
            </span>
          </div>

          {/* Reading Time Duration Control */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
              <Clock className="w-4 h-4 text-[#880c59]" />
              <span>Tiempo de Lectura por Historia:</span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
              {[
                { label: '5.0s (Rápido)', value: 5.0 },
                { label: '6.5s (Recomendado)', value: 6.5 },
                { label: '8.0s (Detenido)', value: 8.0 }
              ].map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setSlideDuration(opt.value)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    slideDuration === opt.value
                      ? 'bg-white text-[#880c59] shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-600">
            Renderizado cinematográfico luminoso con tipografía nítida, transiciones con ritmo y música sincronizada de modum.
          </p>

          {videoProgress.status === 'idle' && (
            <button
              onClick={handleStartRecording}
              className="w-full py-3 px-4 text-xs font-bold text-white bg-gradient-to-r from-[#880c59] via-[#0a3850] to-[#880c59] hover:brightness-110 rounded-xl shadow-md shadow-[#880c59]/20 transition-all flex items-center justify-center gap-2"
            >
              <Video className="w-4 h-4" />
              <span>Generar y Descargar Video MP4</span>
            </button>
          )}

          {videoProgress.status === 'recording' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-700 font-medium">{videoProgress.message}</span>
                <span className="font-mono text-[#880c59] font-bold">{videoProgress.progress}%</span>
              </div>
              <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#880c59] to-[#0a3850] transition-all duration-150"
                  style={{ width: `${videoProgress.progress}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 text-center animate-pulse">
                Renderizando fotogramas luminosos y ensamblando MP4 con audio...
              </p>
            </div>
          )}

          {videoProgress.status === 'done' && (
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600">
                <CheckCircle2 className="w-4 h-4" />
                <span>¡Video MP4 listo para descargar y compartir directamente!</span>
              </div>

              {videoProgress.videoUrl && (
                <div className="flex items-center justify-center bg-slate-900 rounded-xl p-2 max-h-56 overflow-hidden shadow-inner">
                  <video
                    src={videoProgress.videoUrl}
                    controls
                    autoPlay
                    loop
                    className="max-h-52 rounded-lg"
                  />
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={handleDownloadRecordedVideo}
                  className="flex-1 py-3 px-4 text-xs font-extrabold text-white bg-[#880c59] hover:bg-[#6e0a47] rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>Descargar Video MP4 (1080×1920)</span>
                </button>
                <button
                  onClick={handleStartRecording}
                  className="py-2.5 px-3 text-xs text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-xl transition-colors shadow-xs"
                >
                  Regenerar
                </button>
              </div>
            </div>
          )}

          {videoProgress.status === 'error' && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>{videoProgress.message}</span>
              </div>
              <button
                onClick={handleStartRecording}
                className="px-2.5 py-1 bg-red-600 text-white hover:bg-red-700 rounded text-[11px] font-bold"
              >
                Reintentar
              </button>
            </div>
          )}
        </div>

        {/* SECTION 2: Slide Images Pack */}
        <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileArchive className="w-4 h-4 text-[#880c59]" />
              <span>2. Paquete de Diapositivas en Imágenes (PNG HD)</span>
            </h4>
            <span className="text-[11px] text-slate-500">{totalSlides} láminas individuales</span>
          </div>
          <p className="text-xs text-slate-600">
            Descarga individual o en lote de las diapositivas para publicar en carrusel de LinkedIn o historias estáticas.
          </p>
          <button
            onClick={handleDownloadAllSlides}
            disabled={isExportingAllSlides}
            className="w-full py-2.5 px-4 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-[#880c59]" />
            <span>
              {isExportingAllSlides
                ? `Exportando ${totalSlides} Diapositivas...`
                : `Descargar las ${totalSlides} Diapositivas en PNG`}
            </span>
          </button>
        </div>

        {/* SECTION 3: Social Media Copy Generator */}
        <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Share2 className="w-4 h-4 text-[#0a3850]" />
              <span>3. Texto Listo para Redes Sociales</span>
            </h4>
            <button
              onClick={handleCopyCaption}
              className="flex items-center gap-1.5 text-xs text-[#880c59] font-semibold hover:underline"
            >
              {copiedCaption ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>¡Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar Texto</span>
                </>
              )}
            </button>
          </div>
          <textarea
            readOnly
            rows={5}
            value={socialCaption}
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl text-slate-700 font-mono resize-none focus:outline-none shadow-xs"
          />
        </div>
      </div>
    </div>
  );
};
