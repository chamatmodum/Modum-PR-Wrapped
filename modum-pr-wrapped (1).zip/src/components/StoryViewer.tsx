import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Play,
  Pause,
  Download,
  Video,
  Volume2,
  VolumeX,
  Maximize2,
  Palette,
  Check
} from 'lucide-react';
import { ClientAccount, PRMilestone, DesignTheme, FontSizeScale } from '../types';
import { audioSynth } from '../utils/audioSynth';
import { exportSlideAsPNG } from '../utils/canvasExporter';
import { getContrastTextColor } from '../utils/colorContrast';
import { ModumLogo } from './ModumLogo';

interface StoryViewerProps {
  account: ClientAccount;
  onOpenVideoExport: () => void;
  onOpenFullscreen: () => void;
  onUpdateTheme?: (theme: DesignTheme) => void;
}

// 7.5 seconds per slide: generous reading time for headlines and descriptions
const SLIDE_DURATION = 7500;

export const StoryViewer: React.FC<StoryViewerProps> = ({
  account,
  onOpenVideoExport,
  onOpenFullscreen,
  onUpdateTheme
}) => {
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(audioSynth.getMuted());
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(audioSynth.getIsPlaying());
  const [isExportingSlide, setIsExportingSlide] = useState<boolean>(false);

  const rawTheme = account.designTheme as string | undefined;
  const activeTheme: DesignTheme =
    rawTheme === 'editorial-press' || rawTheme === 'neon-billboard'
      ? rawTheme
      : 'kinetic-pop';

  const fontSizeScale: FontSizeScale = account.fontSize || 'normal';

  // Total slides = Intro + dynamic milestones + Outro
  const totalSlides = account.milestones.length + 2;

  useEffect(() => {
    if (currentSlide >= totalSlides) {
      setCurrentSlide(0);
      setProgress(0);
    }
  }, [totalSlides, currentSlide]);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => {
      const next = (prev + 1) % totalSlides;
      audioSynth.playWhoosh();
      return next;
    });
    setProgress(0);
  }, [totalSlides]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => {
      const next = prev === 0 ? totalSlides - 1 : prev - 1;
      audioSynth.playWhoosh();
      return next;
    });
    setProgress(0);
  }, [totalSlides]);

  // Handle timer for auto-advancing slides
  useEffect(() => {
    if (isPaused) return;

    const intervalTime = 50;
    const step = (intervalTime / SLIDE_DURATION) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          nextSlide();
          return 0;
        }
        return prev + step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPaused, nextSlide]);

  // Keyboard navigation - Never intercept spacebar or letters when typing in form inputs!
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        prevSlide();
      } else if (e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        setIsPaused((p) => !p);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const handleToggleAudio = () => {
    if (!isAudioPlaying) {
      audioSynth.startBeat();
      setIsAudioPlaying(true);
      audioSynth.setMuted(false);
      setIsMuted(false);
    } else {
      const nextMute = !isMuted;
      audioSynth.setMuted(nextMute);
      setIsMuted(nextMute);
    }
  };

  const handleDownloadCurrentSlide = async () => {
    try {
      setIsExportingSlide(true);
      const dataUrl = await exportSlideAsPNG(account, currentSlide);
      const link = document.createElement('a');
      const slideLabel =
        currentSlide === 0
          ? 'Intro'
          : currentSlide === totalSlides - 1
          ? 'Outro'
          : `Hito_0${currentSlide}`;
      link.download = `modum_${account.clientName.replace(/\s+/g, '_')}_${slideLabel}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Error downloading slide:', err);
    } finally {
      setIsExportingSlide(false);
    }
  };

  const currentMilestone: PRMilestone | null =
    currentSlide >= 1 && currentSlide <= account.milestones.length
      ? account.milestones[currentSlide - 1]
      : null;

  const animationStyle = account.animationStyle || 'directional';

  const themesList: { id: DesignTheme; label: string; icon: string }[] = [
    { id: 'kinetic-pop', label: 'Spotify Wrapped', icon: '⚡' },
    { id: 'editorial-press', label: 'Editorial Forbes', icon: '📰' },
    { id: 'neon-billboard', label: 'Billboard Neón', icon: '✨' }
  ];

  const isNeon = activeTheme === 'neon-billboard';
  const isEditorial = activeTheme === 'editorial-press';
  const logoVariant = isNeon ? 'dark' : 'light';
  const accentTextColor = getContrastTextColor(account.contrastColor);

  // Subtle high-contrast text shadows per background mode
  const lightTextShadow = '[text-shadow:0_2px_10px_rgba(255,255,255,0.95),0_1px_2px_rgba(15,23,42,0.12)]';
  const darkTextShadow = '[text-shadow:0_2px_14px_rgba(0,0,0,0.92),0_1px_3px_rgba(0,0,0,0.85)]';
  const textShadowClass = isNeon ? darkTextShadow : lightTextShadow;

  // Dynamic Font Size Classes based on user's Editor selection
  const metricSizeClass =
    fontSizeScale === 'compact'
      ? 'text-5xl'
      : fontSizeScale === 'large'
      ? 'text-6xl sm:text-[4.5rem]'
      : 'text-5xl sm:text-6xl';

  const labelSizeClass =
    fontSizeScale === 'compact'
      ? 'text-[11px] sm:text-xs'
      : fontSizeScale === 'large'
      ? 'text-sm sm:text-base'
      : 'text-xs sm:text-sm';

  const headlineSizeClass =
    fontSizeScale === 'compact'
      ? 'text-lg sm:text-xl'
      : fontSizeScale === 'large'
      ? 'text-2xl sm:text-[1.7rem]'
      : 'text-xl sm:text-2xl';

  const descSizeClass =
    fontSizeScale === 'compact'
      ? 'text-xs sm:text-[13px]'
      : fontSizeScale === 'large'
      ? 'text-base sm:text-[17px]'
      : 'text-sm sm:text-[15px]';

  const containerBg = isNeon
    ? 'bg-[#080e14] text-white border-slate-800 shadow-cyan-950/40'
    : isEditorial
    ? 'bg-[#fbfaf6] text-stone-950 border-amber-950/15 shadow-amber-900/10'
    : 'bg-[#f8fafc] text-slate-950 border-slate-200 shadow-slate-400/25';

  return (
    <div className="flex flex-col items-center justify-center py-2 space-y-4">
      {/* Quick 1-Click Design Theme Selector Bar */}
      {onUpdateTheme && (
        <div className="w-full max-w-[420px] bg-white border border-slate-200/90 rounded-2xl p-2 shadow-xs flex items-center justify-between gap-1.5">
          <div className="flex items-center gap-1.5 pl-2 text-xs font-bold text-slate-700 whitespace-nowrap">
            <Palette className="w-3.5 h-3.5 text-[#880c59]" />
            <span className="hidden sm:inline">Diseño:</span>
          </div>

          <div className="flex items-center gap-1 overflow-x-auto py-0.5 no-scrollbar">
            {themesList.map((t) => (
              <button
                key={t.id}
                onClick={() => onUpdateTheme(t.id)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 whitespace-nowrap ${
                  activeTheme === t.id
                    ? 'bg-[#880c59] text-white shadow-xs scale-102'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>{t.icon}</span>
                <span>{t.label}</span>
                {activeTheme === t.id && <Check className="w-3 h-3 ml-0.5" />}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Viewer Container in 9:16 ratio */}
      <div
        className={`relative w-full max-w-[390px] aspect-[9/16] rounded-3xl overflow-hidden shadow-2xl border select-none flex flex-col justify-between transition-colors duration-500 ${containerBg}`}
      >
        {/* Dynamic Animated Ambient Background */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {isNeon ? (
            <>
              <div
                className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[90px] opacity-35"
                style={{ backgroundColor: '#ff007f' }}
              />
              <div
                className="absolute -bottom-24 -left-24 w-88 h-88 rounded-full blur-[100px] opacity-30"
                style={{ backgroundColor: '#00e5ff' }}
              />
              <div
                className="absolute top-1/3 left-1/4 w-72 h-72 rounded-full blur-[90px] opacity-25"
                style={{ backgroundColor: account.contrastColor }}
              />
              <div className="absolute inset-0 bg-[radial-gradient(rgba(0,229,255,0.08)_1px,transparent_1px)] [background-size:24px_24px] opacity-80" />
            </>
          ) : isEditorial ? (
            <>
              <div
                className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[80px] opacity-18"
                style={{ backgroundColor: '#880c59' }}
              />
              <div
                className="absolute -bottom-24 -left-24 w-88 h-88 rounded-full blur-[90px] opacity-16"
                style={{ backgroundColor: account.contrastColor }}
              />
              <div className="absolute inset-0 bg-[radial-gradient(rgba(136,12,89,0.03)_1px,transparent_1px)] [background-size:32px_32px]" />
            </>
          ) : (
            <>
              <div
                className="absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[80px] opacity-24"
                style={{ backgroundColor: '#880c59' }}
              />
              <div
                className="absolute -bottom-24 -left-24 w-88 h-88 rounded-full blur-[90px] opacity-22"
                style={{ backgroundColor: '#0a3850' }}
              />
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 0.34, scale: 1.15 }}
                transition={{ duration: 0.8 }}
                className="absolute top-1/3 left-1/4 w-72 h-72 rounded-full blur-[80px]"
                style={{ backgroundColor: account.contrastColor }}
              />
              <div className="absolute inset-0 bg-[radial-gradient(rgba(10,56,80,0.05)_1px,transparent_1px)] [background-size:24px_24px] opacity-70" />
            </>
          )}
        </div>

        {/* TOP OVERLAY: Progress bars and Header lockup (Standard Modum logo in presentation) */}
        <div className="relative z-20 pt-4 px-4 pb-2 space-y-3">
          {/* Segmented Progress Bars */}
          <div className="flex items-center gap-1.5 w-full">
            {Array.from({ length: totalSlides }).map((_, idx) => {
              let fillWidth = '0%';
              if (idx < currentSlide) {
                fillWidth = '100%';
              } else if (idx === currentSlide) {
                fillWidth = `${progress}%`;
              }

              return (
                <div
                  key={idx}
                  onClick={(e) => {
                    e.stopPropagation();
                    setCurrentSlide(idx);
                    setProgress(0);
                    audioSynth.playWhoosh();
                  }}
                  className={`flex-1 h-1.5 rounded-full overflow-hidden cursor-pointer hover:h-2 transition-all ${
                    isNeon ? 'bg-slate-800' : 'bg-slate-300/80'
                  }`}
                >
                  <div
                    className="h-full rounded-full transition-all duration-75"
                    style={{
                      width: fillWidth,
                      backgroundColor:
                        idx === currentSlide
                          ? isNeon
                            ? '#ff007f'
                            : '#880c59'
                          : isNeon
                          ? account.contrastColor
                          : '#0f172a'
                    }}
                  />
                </div>
              );
            })}
          </div>

          {/* Top Header Lockup: Standard Modum Logo + Year + Client Logo */}
          <div className="flex items-center justify-between text-xs gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <ModumLogo
                variant={logoVariant}
                edition="standard"
                className="h-6 w-auto object-contain shrink-0"
              />
              <span
                className={`font-extrabold text-[11px] tracking-wide border-l pl-2 ${
                  isNeon ? 'text-slate-200 border-slate-700' : 'text-slate-700 border-slate-300'
                }`}
              >
                {account.year}
              </span>
            </div>

            {/* Client Logo in Header Pill + Pause */}
            <div className="flex items-center gap-1.5 shrink-0">
              {account.clientLogo ? (
                <div
                  className={`h-7 px-2 py-0.5 rounded-lg flex items-center justify-center max-w-[110px] border ${
                    isNeon
                      ? 'bg-slate-900/95 border-slate-700/90 shadow-xs'
                      : 'bg-white shadow-sm border-slate-200/90'
                  }`}
                >
                  <img
                    src={account.clientLogo}
                    alt={account.clientName}
                    className="h-full max-w-[90px] object-contain"
                  />
                </div>
              ) : (
                <span
                  className={`font-black text-[11px] tracking-wider truncate max-w-[110px] ${
                    isNeon ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  {account.clientName.toUpperCase()}
                </span>
              )}

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsPaused(!isPaused);
                }}
                className={`p-1.5 rounded-full transition-colors ${
                  isNeon
                    ? 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                    : 'bg-slate-200/90 text-slate-800 hover:bg-slate-300'
                }`}
                title={isPaused ? 'Reanudar' : 'Pausar'}
              >
                {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        {/* INTERACTIVE TAP ZONES */}
        <div
          className="absolute inset-y-16 left-0 w-1/3 z-10 cursor-pointer"
          onClick={prevSlide}
          title="Toca para retroceder"
        />
        <div
          className="absolute inset-y-16 right-0 w-2/3 z-10 cursor-pointer"
          onClick={nextSlide}
          title="Toca para avanzar"
        />

        {/* MIDDLE CONTENT */}
        <div className="relative z-10 flex-1 px-5 flex flex-col justify-center pointer-events-none">
          <AnimatePresence mode="wait">
            {/* SCENE 0: INTRO */}
            {currentSlide === 0 && (
              <motion.div
                key="intro"
                initial={
                  animationStyle === 'directional'
                    ? { opacity: 0, y: 35 }
                    : { opacity: 0, scale: 0.92 }
                }
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -25 }}
                transition={{ duration: 0.4 }}
                className="space-y-4"
              >
                <div className="space-y-1.5 text-center">
                  <motion.div
                    initial={
                      animationStyle === 'directional' ? { opacity: 0, y: -20 } : { opacity: 0 }
                    }
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05, duration: 0.35 }}
                    className="flex flex-col items-center gap-1"
                  >
                    <ModumLogo
                      variant={logoVariant}
                      edition="standard"
                      className="h-8 w-auto object-contain"
                    />
                    <span
                      className={`text-[10px] font-black tracking-[0.25em] uppercase ${textShadowClass} ${
                        isNeon ? 'text-pink-300' : 'text-slate-700'
                      }`}
                    >
                      presenta
                    </span>
                  </motion.div>

                  <motion.div
                    initial={
                      animationStyle === 'directional'
                        ? { opacity: 0, y: 40, scale: 0.9 }
                        : { opacity: 0 }
                    }
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ delay: 0.12, duration: 0.4 }}
                    className={`font-black text-6xl sm:text-7xl tracking-tighter leading-none ${textShadowClass} ${
                      isEditorial
                        ? 'font-serif text-[#880c59] italic'
                        : isNeon
                        ? 'font-display text-pink-400 drop-shadow-[0_0_24px_rgba(255,0,127,0.65)]'
                        : 'font-display text-[#880c59]'
                    }`}
                  >
                    {account.year}
                  </motion.div>
                  <motion.h1
                    initial={
                      animationStyle === 'directional' ? { opacity: 0, x: 40 } : { opacity: 0 }
                    }
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.18, duration: 0.35 }}
                    className={`font-black text-4xl sm:text-5xl tracking-tight leading-none font-display ${textShadowClass} ${
                      isNeon ? 'text-white' : 'text-slate-950'
                    }`}
                  >
                    WRAPPED
                  </motion.h1>
                </div>

                {/* PROMINENT LOGO HERO CARD */}
                <motion.div
                  initial={
                    animationStyle === 'directional' ? { opacity: 0, y: 30 } : { opacity: 0 }
                  }
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.22, duration: 0.4 }}
                  className={`rounded-3xl p-5 border flex flex-col items-center justify-center space-y-3.5 ${
                    isNeon
                      ? 'bg-slate-900/95 border-slate-700 shadow-xl shadow-cyan-950/30'
                      : isEditorial
                      ? 'bg-white/98 border-amber-900/15 shadow-xl'
                      : 'bg-white/98 backdrop-blur-xl border-slate-200 shadow-xl shadow-slate-300/40'
                  }`}
                >
                  <div
                    className={`w-full h-24 rounded-2xl p-3 flex items-center justify-center border overflow-hidden ${
                      isNeon ? 'bg-black/90 border-slate-700' : 'bg-white border-slate-100 shadow-xs'
                    }`}
                  >
                    {account.clientLogo ? (
                      <img
                        src={account.clientLogo}
                        alt={account.clientName}
                        className="max-h-full max-w-full object-contain"
                      />
                    ) : (
                      <span className="font-display font-black text-2xl text-[#0a3850]">
                        {account.clientName}
                      </span>
                    )}
                  </div>

                  <div className="text-center space-y-0.5">
                    <h2
                      className={`font-black text-xl ${
                        isNeon ? 'text-white' : 'text-slate-950'
                      } ${isEditorial ? 'font-serif' : 'font-display'}`}
                    >
                      {account.clientName}
                    </h2>
                    <p
                      className={`text-xs font-bold ${
                        isNeon ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      {account.clientIndustry}
                    </p>
                  </div>

                  {/* High Contrast Emphasis Accent Bar */}
                  <div
                    className={`w-full py-2 px-3 rounded-xl text-center text-xs font-black uppercase tracking-wider border ${
                      isNeon
                        ? 'bg-slate-950/90'
                        : isEditorial
                        ? 'bg-[#880c59] text-white border-[#880c59] shadow-sm'
                        : 'border-slate-900/15 shadow-xs'
                    }`}
                    style={
                      isEditorial
                        ? undefined
                        : isNeon
                        ? { borderColor: account.contrastColor, color: account.contrastColor }
                        : {
                            backgroundColor: account.contrastColor,
                            color: accentTextColor
                          }
                    }
                  >
                    {account.milestones.length} Grandes Hitos del Año
                  </div>
                </motion.div>

                <p
                  className={`text-xs text-center font-extrabold tracking-wide ${textShadowClass} ${
                    isNeon ? 'text-slate-200' : 'text-slate-700'
                  }`}
                >
                  Toca la pantalla para descubrir el impacto →
                </p>
              </motion.div>
            )}

            {/* SCENES 1 TO N: MILESTONES */}
            {currentSlide >= 1 &&
              currentSlide <= account.milestones.length &&
              currentMilestone && (
                <motion.div
                  key={`milestone-${currentSlide}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-3"
                >
                  {/* Top Bar: Index & Straight High-Contrast Sticker Badge */}
                  <motion.div
                    initial={
                      animationStyle === 'directional'
                        ? { opacity: 0, x: -50 }
                        : { opacity: 0, y: -15 }
                    }
                    animate={{ opacity: 1, x: 0, y: 0 }}
                    transition={{ delay: 0.05, duration: 0.35 }}
                    className="flex items-center justify-between gap-2"
                  >
                    <div className={`flex items-center gap-1.5 ${textShadowClass}`}>
                      <span
                        className={`font-black text-2xl sm:text-3xl ${
                          isNeon
                            ? 'text-pink-400 font-display'
                            : isEditorial
                            ? 'text-[#880c59] font-serif'
                            : 'text-[#880c59] font-display'
                        }`}
                      >
                        0{currentSlide}
                      </span>
                      <span
                        className={`font-mono text-xs font-extrabold ${
                          isNeon ? 'text-slate-300' : 'text-slate-600'
                        }`}
                      >
                        / 0{account.milestones.length}
                      </span>
                    </div>

                    {/* Straight (NOT rotated) Sticker / Badge Tag */}
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase shadow-sm ${
                        isNeon
                          ? 'bg-pink-500/25 text-pink-200 border border-pink-400/70 shadow-[0_0_12px_rgba(255,0,127,0.35)]'
                          : isEditorial
                          ? 'bg-[#880c59] text-white tracking-widest'
                          : 'font-black border border-slate-900/15'
                      }`}
                      style={
                        !isNeon && !isEditorial
                          ? {
                              backgroundColor: account.contrastColor,
                              color: accentTextColor
                            }
                          : undefined
                      }
                    >
                      {currentMilestone.stickerBadge || 'HITO ESTRATÉGICO'}
                    </div>
                  </motion.div>

                  {/* 1. CIFRA & 2. ETIQUETA (Subtle shadow + increased contrast + dynamic font size) */}
                  <div className="space-y-1">
                    <motion.div
                      initial={
                        animationStyle === 'directional'
                          ? { y: 40, scale: 0.88, opacity: 0 }
                          : animationStyle === 'zoom'
                          ? { scale: 0.7, opacity: 0 }
                          : { opacity: 0, y: 20 }
                      }
                      animate={{ y: 0, scale: 1, opacity: 1 }}
                      transition={{ delay: 0.1, duration: 0.4 }}
                      className={`font-black ${metricSizeClass} tracking-tighter tabular-nums leading-none ${textShadowClass} ${
                        isNeon
                          ? 'font-display drop-shadow-[0_0_22px_rgba(0,229,255,0.55)]'
                          : isEditorial
                          ? 'text-[#052638] font-serif'
                          : 'text-[#052638] font-display'
                      }`}
                      style={isNeon ? { color: account.contrastColor } : undefined}
                    >
                      {currentMilestone.metricValue}
                    </motion.div>

                    <motion.div
                      initial={
                        animationStyle === 'directional'
                          ? { opacity: 0, x: 50 }
                          : { opacity: 0 }
                      }
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.18, duration: 0.35 }}
                      className={`${labelSizeClass} font-black uppercase tracking-wider ${textShadowClass} ${
                        isNeon ? 'text-pink-300' : 'text-[#7a0a50]'
                      }`}
                    >
                      {currentMilestone.metricLabel}
                    </motion.div>
                  </div>

                  <div
                    className="h-0.5 w-full rounded-full"
                    style={{
                      backgroundColor: isNeon
                        ? 'rgba(255,255,255,0.18)'
                        : `${account.contrastColor}`
                    }}
                  />

                  {/* 3. TITULAR (Higher Contrast + Subtle Shadow + Dynamic Font Size) */}
                  <motion.h2
                    initial={
                      animationStyle === 'directional'
                        ? { opacity: 0, x: -45 }
                        : { opacity: 0, y: 15 }
                    }
                    animate={{ opacity: 1, x: 0, y: 0 }}
                    transition={{ delay: 0.22, duration: 0.4 }}
                    className={`font-black ${headlineSizeClass} leading-tight ${textShadowClass} ${
                      isNeon
                        ? 'text-white font-display'
                        : isEditorial
                        ? 'font-serif text-stone-950 leading-snug'
                        : 'font-display text-slate-950'
                    }`}
                  >
                    {isEditorial && '“'}
                    {currentMilestone.headline}
                    {isEditorial && '”'}
                  </motion.h2>

                  {/* OPTIONAL REFERENCE IMAGE */}
                  {currentMilestone.image && (
                    <motion.div
                      initial={
                        animationStyle === 'directional'
                          ? { opacity: 0, scale: 0.92, y: 20 }
                          : { opacity: 0 }
                      }
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      transition={{ delay: 0.28, duration: 0.35 }}
                      className={`w-full h-32 rounded-2xl overflow-hidden border shadow-sm relative ${
                        isNeon ? 'border-slate-700 bg-slate-950' : 'border-slate-300/80 bg-slate-100'
                      }`}
                    >
                      <img
                        src={currentMilestone.image}
                        alt="Evidencia del Hito"
                        className="w-full h-full object-cover"
                      />
                    </motion.div>
                  )}

                  {/* 4. DESCRIPCIÓN (High-contrast card + subtle text shadow + dynamic font size) */}
                  <motion.div
                    initial={
                      animationStyle === 'directional'
                        ? { opacity: 0, y: 35 }
                        : { opacity: 0 }
                    }
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.32, duration: 0.35 }}
                    className={`p-3.5 sm:p-4 rounded-2xl border ${descSizeClass} font-semibold leading-relaxed shadow-sm ${
                      isNeon
                        ? 'bg-slate-950/92 border-slate-700 text-white [text-shadow:0_1px_4px_rgba(0,0,0,0.85)]'
                        : isEditorial
                        ? 'bg-white/98 border-amber-900/15 text-stone-950'
                        : 'bg-white/98 border-slate-300/80 text-slate-950'
                    }`}
                  >
                    {currentMilestone.description}
                  </motion.div>

                  {/* Transparent Standard Modum Logo Stamp at bottom of Milestone slide */}
                  <div className="pt-1 flex items-center justify-center opacity-95">
                    <ModumLogo
                      variant={logoVariant}
                      edition="standard"
                      className="h-5 w-auto object-contain"
                    />
                  </div>
                </motion.div>
              )}

            {/* SCENE OUTRO: MODUM 10 AÑOS CELEBRATORY CLOSING (NO SUMMARY LIST) */}
            {currentSlide === totalSlides - 1 && (
              <motion.div
                key="outro"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                transition={{ duration: 0.35 }}
                className="space-y-5"
              >
                <div className={`text-center space-y-1.5 ${textShadowClass}`}>
                  <span
                    className={`text-xs font-black uppercase tracking-widest ${
                      isNeon ? 'text-pink-300' : 'text-[#880c59]'
                    }`}
                  >
                    Misión Cumplida · {account.year}
                  </span>
                  <h2
                    className={`font-black text-3xl sm:text-4xl tracking-tight leading-none ${
                      isNeon
                        ? 'text-white font-display'
                        : isEditorial
                        ? 'font-serif text-stone-950'
                        : 'font-display text-slate-950'
                    }`}
                  >
                    IMPACTO IMPARABLE
                  </h2>
                </div>

                {/* Celebratory Modum 10 Años Hero Card */}
                <div
                  className={`rounded-3xl p-6 text-center space-y-5 border shadow-xl ${
                    isNeon
                      ? 'bg-slate-950/92 border-slate-700 text-white'
                      : isEditorial
                      ? 'bg-white/98 border-amber-900/15 text-stone-950'
                      : 'bg-white/98 border-slate-300/80 text-slate-950'
                  }`}
                >
                  <div className="flex justify-center">
                    <span
                      className={`px-3.5 py-1 rounded-full text-[11px] font-black uppercase tracking-widest border ${
                        isNeon
                          ? 'bg-slate-900'
                          : isEditorial
                          ? 'bg-[#880c59] text-white border-[#880c59]'
                          : 'border-slate-900/15'
                      }`}
                      style={
                        isEditorial
                          ? undefined
                          : isNeon
                          ? { borderColor: account.contrastColor, color: account.contrastColor }
                          : { backgroundColor: account.contrastColor, color: accentTextColor }
                      }
                    >
                      Edición Especial · 10 Años
                    </span>
                  </div>

                  {/* Prominent Modum 10 Años Image */}
                  <div className="py-2 flex items-center justify-center">
                    <ModumLogo
                      variant={logoVariant}
                      edition="anniversary10"
                      className="h-24 sm:h-28 w-auto object-contain"
                    />
                  </div>

                  <div
                    className="h-px w-full"
                    style={{
                      backgroundColor: isNeon
                        ? 'rgba(255,255,255,0.14)'
                        : 'rgba(15,23,42,0.1)'
                    }}
                  />

                  <div className="space-y-3">
                    {account.clientLogo && (
                      <div className="flex items-center justify-center gap-2.5">
                        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          Junto a
                        </span>
                        <div
                          className={`h-8 px-3 py-1 rounded-xl border flex items-center justify-center ${
                            isNeon ? 'bg-black border-slate-700' : 'bg-white border-slate-200 shadow-2xs'
                          }`}
                        >
                          <img
                            src={account.clientLogo}
                            alt={account.clientName}
                            className="h-full object-contain max-w-[100px]"
                          />
                        </div>
                      </div>
                    )}

                    <p className="text-sm font-bold leading-snug">
                      Gracias por construir un año extraordinario junto a nosotros.
                    </p>
                    <p
                      className={`text-xs font-black ${
                        isNeon ? 'text-pink-300' : 'text-[#880c59]'
                      }`}
                    >
                      ¡Listos para superar la meta en {parseInt(account.year, 10) + 1}!
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* BOTTOM CONTROLS OVERLAY */}
        <div
          className={`relative z-20 p-4 flex items-center justify-between gap-2 border-t ${
            isNeon
              ? 'bg-slate-900/90 border-slate-800'
              : 'bg-gradient-to-t from-slate-100/95 via-slate-100/75 to-transparent border-slate-200/60'
          }`}
        >
          <button
            onClick={handleToggleAudio}
            className={`p-2 rounded-xl border shadow-xs transition-colors ${
              isNeon
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200/90 text-slate-700 hover:bg-slate-50'
            }`}
            title={isAudioPlaying && !isMuted ? 'Silenciar música' : 'Activar beat synth'}
          >
            {isAudioPlaying && !isMuted ? (
              <Volume2 className="w-4 h-4 text-[#880c59]" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>

          <button
            onClick={handleDownloadCurrentSlide}
            disabled={isExportingSlide}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold shadow-xs transition-colors ${
              isNeon
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200/90 text-slate-800 hover:bg-slate-50'
            }`}
            title="Descargar esta diapositiva en alta resolución (1080x1920 PNG)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExportingSlide ? '...' : 'PNG Slide'}</span>
          </button>

          <button
            onClick={onOpenFullscreen}
            className={`p-2 rounded-xl border shadow-xs transition-colors ${
              isNeon
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200/90 text-slate-700 hover:bg-slate-50'
            }`}
            title="Pantalla Completa para juntas"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenVideoExport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-white text-xs font-bold shadow-md shadow-[#880c59]/20 transition-transform active:scale-95 whitespace-nowrap bg-gradient-to-r from-[#880c59] to-[#0a3850]"
          >
            <Video className="w-3.5 h-3.5" />
            <span>Descargar MP4</span>
          </button>
        </div>
      </div>

      {/* Helper guide below viewer */}
      <div className="mt-2 flex flex-wrap items-center justify-center gap-3 text-xs text-slate-500">
        <span>Estilo: {themesList.find((t) => t.id === activeTheme)?.label}</span>
        <span>·</span>
        <span>
          Letra:{' '}
          {fontSizeScale === 'compact'
            ? 'Compacta'
            : fontSizeScale === 'large'
            ? 'Grande'
            : 'Normal'}
        </span>
        <span>·</span>
        <button
          onClick={onOpenVideoExport}
          className="text-[#880c59] font-bold hover:underline flex items-center gap-1"
        >
          <Video className="w-3.5 h-3.5" />
          <span>Generar video MP4 para redes</span>
        </button>
      </div>
    </div>
  );
};
