export type ModumLogoVariant = 'light' | 'dark';
export type ModumLogoEdition = 'standard' | 'anniversary10';

const LOGO_SOURCES: Record<ModumLogoEdition, string> = {
  standard: '/assets/aistudio/Credenciales_Modum_2026_VF.pptx_a2e0cc26.jpg',
  anniversary10: '/assets/aistudio/Portada_ppt_general_fija-04_2d11e43f.png'
};

const dataUrlCache: Record<string, string> = {};
const imageCache: Record<string, HTMLImageElement> = {};
const pendingPromises: Record<string, Promise<string>> = {};

function loadRawImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

function processLogoVariant(
  rawImg: HTMLImageElement,
  variant: ModumLogoVariant,
  fallbackSrc: string
): string {
  const w = rawImg.naturalWidth || rawImg.width;
  const h = rawImg.naturalHeight || rawImg.height;

  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = w;
  srcCanvas.height = h;
  const srcCtx = srcCanvas.getContext('2d', { willReadFrequently: true });
  if (!srcCtx) return fallbackSrc;

  srcCtx.drawImage(rawImg, 0, 0);
  const srcData = srcCtx.getImageData(0, 0, w, h);
  const data = srcData.data;

  // Detect whether the source image already uses an alpha channel for transparency
  let hasAlphaTransparency = false;
  for (let i = 3; i < data.length; i += 16) {
    if (data[i] < 245) {
      hasAlphaTransparency = true;
      break;
    }
  }

  // 1. Find tight bounding box of visible logo pixels
  let minX = w;
  let minY = h;
  let maxX = 0;
  let maxY = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const a = data[idx + 3];

      const isVisible = hasAlphaTransparency
        ? a > 12
        : a > 12 && 255 - Math.min(r, g, b) > 18;

      if (isVisible) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (maxX <= minX || maxY <= minY) {
    return fallbackSrc;
  }

  const pad = 4;
  minX = Math.max(0, minX - pad);
  minY = Math.max(0, minY - pad);
  maxX = Math.min(w - 1, maxX + pad);
  maxY = Math.min(h - 1, maxY + pad);

  const cropW = maxX - minX + 1;
  const cropH = maxY - minY + 1;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = cropW;
  outCanvas.height = cropH;
  const outCtx = outCanvas.getContext('2d');
  if (!outCtx) return fallbackSrc;

  const outImgData = outCtx.createImageData(cropW, cropH);
  const out = outImgData.data;

  // 2. Process cropped pixels (preserve native transparency or strip white background)
  for (let y = 0; y < cropH; y++) {
    for (let x = 0; x < cropW; x++) {
      const sIdx = ((y + minY) * w + (x + minX)) * 4;
      const oIdx = (y * cropW + x) * 4;

      const r = data[sIdx];
      const g = data[sIdx + 1];
      const b = data[sIdx + 2];
      const a = data[sIdx + 3];

      if (a <= 8) {
        out[oIdx] = 0;
        out[oIdx + 1] = 0;
        out[oIdx + 2] = 0;
        out[oIdx + 3] = 0;
        continue;
      }

      let ur = r;
      let ug = g;
      let ub = b;
      let outAlpha = a;

      if (!hasAlphaTransparency) {
        const distFromWhite = 255 - Math.min(r, g, b);
        if (distFromWhite <= 14) {
          out[oIdx] = 0;
          out[oIdx + 1] = 0;
          out[oIdx + 2] = 0;
          out[oIdx + 3] = 0;
          continue;
        }
        const alphaNorm = Math.min(1, (distFromWhite - 14) / 115);
        ur = Math.max(0, Math.min(255, (r - 255 * (1 - alphaNorm)) / alphaNorm));
        ug = Math.max(0, Math.min(255, (g - 255 * (1 - alphaNorm)) / alphaNorm));
        ub = Math.max(0, Math.min(255, (b - 255 * (1 - alphaNorm)) / alphaNorm));
        outAlpha = Math.round(alphaNorm * 255);
      }

      if (variant === 'dark') {
        const isBerry = ur - ug > 22;
        if (isBerry) {
          ur = 244;
          ug = 63;
          ub = 142;
        } else {
          ur = 241;
          ug = 245;
          ub = 249;
        }
      }

      out[oIdx] = Math.round(ur);
      out[oIdx + 1] = Math.round(ug);
      out[oIdx + 2] = Math.round(ub);
      out[oIdx + 3] = outAlpha;
    }
  }

  outCtx.putImageData(outImgData, 0, 0);
  return outCanvas.toDataURL('image/png');
}

export async function getModumLogoDataUrl(
  variant: ModumLogoVariant = 'light',
  edition: ModumLogoEdition = 'standard'
): Promise<string> {
  const key = `${edition}_${variant}`;
  if (dataUrlCache[key]) {
    return dataUrlCache[key];
  }

  const src = LOGO_SOURCES[edition];
  if (!pendingPromises[key]) {
    pendingPromises[key] = (async () => {
      try {
        const raw = await loadRawImage(src);
        const processed = processLogoVariant(raw, variant, src);
        dataUrlCache[key] = processed;
        return processed;
      } catch {
        return src;
      }
    })();
  }

  return pendingPromises[key];
}

export async function getModumLogoImage(
  variant: ModumLogoVariant = 'light',
  edition: ModumLogoEdition = 'standard'
): Promise<HTMLImageElement> {
  const key = `${edition}_${variant}`;
  if (imageCache[key]) {
    return imageCache[key];
  }

  const dataUrl = await getModumLogoDataUrl(variant, edition);
  const img = await loadRawImage(dataUrl);
  imageCache[key] = img;
  return img;
}
