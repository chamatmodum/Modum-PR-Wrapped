// Web Audio API procedural synthesizer for Spotify Wrapped-style energetic beats and scene transition SFX

class WrappedAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private isMuted: boolean = false;
  private masterGain: GainNode | null = null;
  private destinationNode: MediaStreamAudioDestinationNode | null = null;
  private intervalId: number | null = null;
  private step: number = 0;
  private bpm: number = 124;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.6, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
      
      // Destination for video stream recording
      this.destinationNode = this.ctx.createMediaStreamDestination();
      this.masterGain.connect(this.destinationNode);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getAudioStreamDestination(): MediaStreamAudioDestinationNode | null {
    this.initContext();
    return this.destinationNode;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.6, this.ctx.currentTime, 0.05);
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public playWhoosh() {
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      const now = this.ctx.currentTime;

      // Pitch sweep
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(750, now + 0.18);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.35);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(400, now);
      filter.frequency.exponentialRampToValueAtTime(3200, now + 0.18);
      filter.frequency.exponentialRampToValueAtTime(500, now + 0.35);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.4, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.36);
    } catch {
      // Audio fallback quiet
    }
  }

  public playKick(time?: number) {
    if (!this.ctx || !this.masterGain) return;
    const t = time ?? this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.12);

    gain.gain.setValueAtTime(0.7, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.25);
  }

  public playHiHat(time?: number, open: boolean = false) {
    if (!this.ctx || !this.masterGain) return;
    const t = time ?? this.ctx.currentTime;

    // White noise buffer
    const bufferSize = this.ctx.sampleRate * (open ? 0.15 : 0.04);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 7500;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(open ? 0.25 : 0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + (open ? 0.14 : 0.04));

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noise.start(t);
    noise.stop(t + (open ? 0.15 : 0.05));
  }

  public playSynthChord(chordFreqs: number[], time?: number) {
    if (!this.ctx || !this.masterGain) return;
    const t = time ?? this.ctx.currentTime;

    chordFreqs.forEach((freq) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const filter = this.ctx!.createBiquadFilter();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1800, t);
      filter.frequency.exponentialRampToValueAtTime(600, t + 0.4);

      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain!);

      osc.start(t);
      osc.stop(t + 0.46);
    });
  }

  public startBeat() {
    this.initContext();
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.step = 0;

    const stepDuration = 60 / this.bpm / 4; // 16th note in seconds

    // Chord progression in F minor / Ab major (Modum agency moody yet uplifting)
    const chords = [
      [174.61, 220.00, 261.63], // F, A, C
      [207.65, 261.63, 311.13], // Ab, C, Eb
      [155.56, 196.00, 233.08], // Eb, G, Bb
      [185.00, 233.08, 277.18]  // Gb, Bb, Db
    ];

    this.intervalId = window.setInterval(() => {
      if (!this.ctx || !this.isPlaying) return;
      const now = this.ctx.currentTime;

      // Kick on beats 0, 4, 8, 12 (four on the floor)
      if (this.step % 4 === 0) {
        this.playKick(now);
      }

      // Hi-hats on off-beats (2, 6, 10, 14) and 16th groove
      if (this.step % 4 === 2) {
        this.playHiHat(now, false);
      } else if (this.step % 2 === 1 && Math.random() > 0.4) {
        this.playHiHat(now, false);
      }

      // Synth chords on bar start (0, 8)
      if (this.step % 8 === 0) {
        const chordIndex = Math.floor(this.step / 8) % chords.length;
        this.playSynthChord(chords[chordIndex], now);
      }

      this.step = (this.step + 1) % 32;
    }, stepDuration * 1000);
  }

  public stopBeat() {
    this.isPlaying = false;
    if (this.intervalId !== null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public toggleBeat(): boolean {
    if (this.isPlaying) {
      this.stopBeat();
      return false;
    } else {
      this.startBeat();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const audioSynth = new WrappedAudioEngine();
