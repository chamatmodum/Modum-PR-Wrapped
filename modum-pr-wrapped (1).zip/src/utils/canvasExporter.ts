import { ClientAccount, PRMilestone, DesignTheme, FontSizeScale } from '../types';
import { audioSynth } from './audioSynth';
import { getModumLogoImage } from './modumLogo';
import { getContrastTextColor } from './colorContrast';

export const CANVAS_WIDTH = 1080;
export const CANVAS_HEIGHT = 1920;

// Easing functions for motion graphics
function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

function normalizeTheme(theme?: string): DesignTheme {
  if (theme === 'editorial-press' || theme === 'neon-billboard') {
    return theme;
  }
  return 'kinetic-pop';
}

function getFontScaleMultiplier(fontSize?: FontSizeScale): number {
  if (fontSize === 'compact') return 0.86;
  if (fontSize === 'large') return 1.14;
  return 1.0;
}

// Apply subtle readability shadow behind fonts based on light vs dark theme
function applySubtleTextShadow(ctx: CanvasRenderingContext2D, isNeon: boolean, strong = false) {
  if (isNeon) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.92)';
    ctx.shadowBlur = strong ? 22 : 14;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 3;
  } else {
    ctx.shadowColor = 'rgba(255, 255, 255, 0.95)';
    ctx.shadowBlur = strong ? 14 : 8;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 2;
  }
}

function clearShadow(ctx: CanvasRenderingContext2D) {
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
}

// Ensure Google Fonts are loaded into canvas context before recording
export async function ensureFontsLoaded(): Promise<void> {
  if (document.fonts) {
    try {
      await Promise.all([
        document.fonts.load('900 64px "Bricolage Grotesque"'),
        document.fonts.load('800 48px "Plus Jakarta Sans"'),
        document.fonts.load('600 32px "Plus Jakarta Sans"'),
        document.fonts.load('500 28px "Plus Jakarta Sans"'),
        document.fonts.load('700 64px "Playfair Display"'),
        document.fonts.load('900 64px "Playfair Display"')
      ]);
      await document.fonts.ready;
    } catch {
      // fallback quietly
    }
  }
}

// Image loader with memory cache
const imageCache: Map<string, HTMLImageElement> = new Map();
export function loadImage(src: string): Promise<HTMLImageElement> {
  if (imageCache.has(src)) {
    return Promise.resolve(imageCache.get(src)!);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      imageCache.set(src, img);
      resolve(img);
    };
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

// Draw image fitted inside a box preserving aspect ratio
export function drawFittedImage(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  boxX: number,
  boxY: number,
  boxW: number,
  boxH: number,
  align: 'center' | 'left' = 'center'
) {
  const imgW = img.naturalWidth || img.width || 1;
  const imgH = img.naturalHeight || img.height || 1;
  const scale = Math.min(boxW / imgW, boxH / imgH);
  const renderW = imgW * scale;
  const renderH = imgH * scale;
  const renderX = align === 'left' ? boxX : boxX + (boxW - renderW) / 2;
  const renderY = boxY + (boxH - renderH) / 2;

  ctx.drawImage(img, renderX, renderY, renderW, renderH);
}

// Draw image covering a box with rounded corners
export function drawCoverImageRounded(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  boxX: number,
  boxY: number,
  boxW: number,
  boxH: number,
  radius: number = 24
) {
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxW, boxH, radius);
  ctx.clip();

  const imgW = img.naturalWidth || img.width || 1;
  const imgH = img.naturalHeight || img.height || 1;
  const scale = Math.max(boxW / imgW, boxH / imgH);
  const renderW = imgW * scale;
  const renderH = imgH * scale;
  const renderX = boxX + (boxW - renderW) / 2;
  const renderY = boxY + (boxH - renderH) / 2;

  ctx.drawImage(img, renderX, renderY, renderW, renderH);
  ctx.restore();
}

// Draw wrapped text block
export function drawWrappedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  align: CanvasTextAlign = 'left'
): number {
  ctx.textAlign = align;
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, currentY);
      line = words[n] + ' ';
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, currentY);
  return currentY + lineHeight;
}

// Thematic Background (3 styles: kinetic-pop, editorial-press, neon-billboard)
export function drawThematicBackground(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  timeOffset: number = 0,
  intensity: number = 1
) {
  const theme = normalizeTheme(account.designTheme);
  const contrastColor = account.contrastColor || '#00f59b';

  if (theme === 'neon-billboard') {
    ctx.fillStyle = '#080e14';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const x1 = CANVAS_WIDTH * 0.8 + Math.cos(timeOffset * 0.7) * 90;
    const y1 = CANVAS_HEIGHT * 0.25 + Math.sin(timeOffset * 0.6) * 110;
    const grad1 = ctx.createRadialGradient(x1, y1, 50, x1, y1, 750);
    grad1.addColorStop(0, 'rgba(255, 0, 127, 0.38)');
    grad1.addColorStop(0.5, 'rgba(255, 0, 127, 0.1)');
    grad1.addColorStop(1, 'rgba(8, 14, 20, 0)');
    ctx.fillStyle = grad1;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const x2 = CANVAS_WIDTH * 0.2 + Math.sin(timeOffset * 0.8) * 100;
    const y2 = CANVAS_HEIGHT * 0.75 + Math.cos(timeOffset * 0.7) * 100;
    const grad2 = ctx.createRadialGradient(x2, y2, 40, x2, y2, 800);
    grad2.addColorStop(0, contrastColor);
    grad2.addColorStop(0.6, 'rgba(0, 229, 255, 0.05)');
    grad2.addColorStop(1, 'rgba(8, 14, 20, 0)');
    ctx.save();
    ctx.globalAlpha = 0.28 * intensity;
    ctx.fillStyle = grad2;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    ctx.restore();

    ctx.save();
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.06)';
    ctx.lineWidth = 1;
    for (let x = 0; x < CANVAS_WIDTH; x += 120) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, CANVAS_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < CANVAS_HEIGHT; y += 120) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(CANVAS_WIDTH, y);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }

  if (theme === 'editorial-press') {
    ctx.fillStyle = '#fbfaf6';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const x1 = CANVAS_WIDTH * 0.85;
    const y1 = CANVAS_HEIGHT * 0.2;
    const grad1 = ctx.createRadialGradient(x1, y1, 80, x1, y1, 700);
    grad1.addColorStop(0, 'rgba(136, 12, 89, 0.16)');
    grad1.addColorStop(1, 'rgba(251, 250, 246, 0)');
    ctx.fillStyle = grad1;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const x2 = CANVAS_WIDTH * 0.15;
    const y2 = CANVAS_HEIGHT * 0.8;
    const grad2 = ctx.createRadialGradient(x2, y2, 60, x2, y2, 750);
    grad2.addColorStop(0, contrastColor);
    grad2.addColorStop(1, 'rgba(251, 250, 246, 0)');
    ctx.save();
    ctx.globalAlpha = 0.14 * intensity;
    ctx.fillStyle = grad2;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    ctx.restore();
    return;
  }

  // KINETIC POP
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  const x1 = CANVAS_WIDTH * 0.8 + Math.cos(timeOffset * 0.7) * 80;
  const y1 = CANVAS_HEIGHT * 0.25 + Math.sin(timeOffset * 0.6) * 100;
  const grad1 = ctx.createRadialGradient(x1, y1, 80, x1, y1, 800);
  grad1.addColorStop(0, 'rgba(136, 12, 89, 0.22)');
  grad1.addColorStop(0.5, 'rgba(136, 12, 89, 0.07)');
  grad1.addColorStop(1, 'rgba(248, 250, 252, 0)');
  ctx.fillStyle = grad1;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  const x2 = CANVAS_WIDTH * 0.2 + Math.sin(timeOffset * 0.8) * 90;
  const y2 = CANVAS_HEIGHT * 0.75 + Math.cos(timeOffset * 0.7) * 90;
  const grad2 = ctx.createRadialGradient(x2, y2, 60, x2, y2, 850);
  grad2.addColorStop(0, 'rgba(10, 56, 80, 0.2)');
  grad2.addColorStop(0.6, 'rgba(10, 56, 80, 0.06)');
  grad2.addColorStop(1, 'rgba(248, 250, 252, 0)');
  ctx.fillStyle = grad2;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  const x3 = CANVAS_WIDTH * 0.5 + Math.sin(timeOffset * 1.1) * 70;
  const y3 = CANVAS_HEIGHT * 0.45 + Math.cos(timeOffset * 0.9) * 80;
  const grad3 = ctx.createRadialGradient(x3, y3, 40, x3, y3, 650);
  grad3.addColorStop(0, contrastColor);
  grad3.addColorStop(0.4, 'rgba(255, 255, 255, 0.2)');
  grad3.addColorStop(1, 'rgba(248, 250, 252, 0)');

  ctx.save();
  ctx.globalAlpha = 0.26 * intensity;
  ctx.fillStyle = grad3;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
  ctx.restore();
}

// Top header with smooth progress bars and standard transparent Modum logo
export async function drawTopHeader(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  activeSceneIndex: number,
  totalScenes: number,
  slideProgress: number = 0
) {
  const isNeon = normalizeTheme(account.designTheme) === 'neon-billboard';
  const contrastColor = account.contrastColor || '#00f59b';
  const barGap = 10;
  const margin = 70;
  const barWidth = (CANVAS_WIDTH - margin * 2 - barGap * (totalScenes - 1)) / totalScenes;
  const barY = 60;
  const barHeight = 8;

  // Draw progress bars
  for (let i = 0; i < totalScenes; i++) {
    const x = margin + i * (barWidth + barGap);

    ctx.fillStyle = isNeon ? 'rgba(255, 255, 255, 0.18)' : 'rgba(15, 23, 42, 0.15)';
    ctx.beginPath();
    ctx.roundRect(x, barY, barWidth, barHeight, 4);
    ctx.fill();

    if (i < activeSceneIndex) {
      ctx.fillStyle = isNeon ? contrastColor : '#0f172a';
      ctx.beginPath();
      ctx.roundRect(x, barY, barWidth, barHeight, 4);
      ctx.fill();
    } else if (i === activeSceneIndex) {
      const currentFillW = barWidth * clamp(slideProgress, 0, 1);
      ctx.fillStyle = isNeon ? '#ff007f' : '#880c59';
      ctx.beginPath();
      ctx.roundRect(x, barY, currentFillW, barHeight, 4);
      ctx.fill();
    }
  }

  // Standard transparent Modum logo in presentation header
  const headerY = 138;
  ctx.save();
  let dividerX = margin + 215;
  try {
    const modumImg = await getModumLogoImage(isNeon ? 'dark' : 'light', 'standard');
    const maxW = 210;
    const maxH = 62;
    const scale = Math.min(maxW / (modumImg.naturalWidth || 1), maxH / (modumImg.naturalHeight || 1));
    const renderedW = (modumImg.naturalWidth || 1) * scale;
    drawFittedImage(ctx, modumImg, margin, headerY - 42, maxW, maxH, 'left');
    dividerX = margin + renderedW + 18;
  } catch {
    ctx.fillStyle = isNeon ? '#ffffff' : '#880c59';
    ctx.font = '900 34px "Bricolage Grotesque", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('modum', margin, headerY);
  }

  ctx.strokeStyle = isNeon ? 'rgba(255,255,255,0.28)' : 'rgba(15,23,42,0.22)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(dividerX, headerY - 30);
  ctx.lineTo(dividerX, headerY + 4);
  ctx.stroke();

  ctx.fillStyle = isNeon ? '#f1f5f9' : '#334155';
  ctx.font = '800 24px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`${account.year}`, dividerX + 18, headerY - 4);

  // Client pill in header
  const logoPillW = 240;
  const logoPillH = 58;
  const logoPillX = CANVAS_WIDTH - margin - logoPillW;
  const logoPillY = headerY - 40;

  ctx.fillStyle = isNeon ? '#0f172a' : '#ffffff';
  ctx.shadowColor = isNeon ? 'rgba(0, 229, 255, 0.2)' : 'rgba(15, 23, 42, 0.1)';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.roundRect(logoPillX, logoPillY, logoPillW, logoPillH, 16);
  ctx.fill();
  clearShadow(ctx);

  ctx.strokeStyle = isNeon ? 'rgba(0, 229, 255, 0.35)' : 'rgba(15, 23, 42, 0.14)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  if (account.clientLogo) {
    try {
      const img = await loadImage(account.clientLogo);
      drawFittedImage(ctx, img, logoPillX + 14, logoPillY + 8, logoPillW - 28, logoPillH - 16);
    } catch {
      ctx.fillStyle = isNeon ? '#ffffff' : '#0f172a';
      ctx.font = '800 22px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(account.clientName.slice(0, 14), logoPillX + logoPillW / 2, logoPillY + 36);
    }
  } else {
    ctx.fillStyle = isNeon ? '#ffffff' : '#0f172a';
    ctx.font = '800 22px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(account.clientName.slice(0, 14), logoPillX + logoPillW / 2, logoPillY + 36);
  }
  ctx.restore();
}

// Scene 0: Intro (Standard Transparent Modum Logo + Client Logo Hero Card)
export async function renderIntroScene(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  timeOffset: number = 0,
  slideProgress: number = 1
) {
  const theme = normalizeTheme(account.designTheme);
  const isNeon = theme === 'neon-billboard';
  const isEditorial = theme === 'editorial-press';
  const contrastColor = account.contrastColor || '#00f59b';
  const accentTextColor = getContrastTextColor(contrastColor);

  const totalScenes = account.milestones.length + 2;
  drawThematicBackground(ctx, account, timeOffset, 1.2);
  await drawTopHeader(ctx, account, 0, totalScenes, slideProgress);

  const t = easeOutCubic(clamp(slideProgress * 2.5, 0, 1));
  const margin = 80;
  const centerY = CANVAS_HEIGHT * 0.35;

  ctx.save();
  ctx.textAlign = 'center';

  // Official transparent standard Modum logo + "PRESENTA"
  try {
    const modumImg = await getModumLogoImage(isNeon ? 'dark' : 'light', 'standard');
    ctx.globalAlpha = t;
    drawFittedImage(ctx, modumImg, CANVAS_WIDTH / 2 - 150, centerY - 235, 300, 86, 'center');
  } catch {
    // quiet fallback
  }

  const tagOffset = (1 - t) * 60;
  applySubtleTextShadow(ctx, isNeon);
  ctx.fillStyle = isNeon ? '#f9a8d4' : isEditorial ? '#880c59' : '#334155';
  ctx.font = '900 24px "Plus Jakarta Sans", sans-serif';
  ctx.letterSpacing = '4px';
  ctx.fillText('PRESENTA', CANVAS_WIDTH / 2 - tagOffset, centerY - 120);
  ctx.letterSpacing = '0px';

  // Big Typography: Year
  const yearY = centerY - 5 - (1 - t) * 50;
  ctx.globalAlpha = t;
  if (isNeon) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
    ctx.shadowBlur = 24;
    ctx.fillStyle = '#ff2e93';
  } else {
    applySubtleTextShadow(ctx, false, true);
    ctx.fillStyle = '#880c59';
  }

  const yearFontFamily = isEditorial ? '"Playfair Display"' : '"Bricolage Grotesque"';
  ctx.font = `900 160px ${yearFontFamily}, "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(account.year, CANVAS_WIDTH / 2, yearY);

  // Main Wrapped Title
  applySubtleTextShadow(ctx, isNeon, true);
  ctx.fillStyle = isNeon ? '#ffffff' : '#090d16';
  ctx.font = '900 92px "Bricolage Grotesque", "Plus Jakarta Sans", sans-serif';
  ctx.fillText('WRAPPED', CANVAS_WIDTH / 2 + tagOffset, yearY + 102);
  clearShadow(ctx);
  ctx.restore();

  // PROMINENT CLIENT LOGO HERO CARD
  const cardY = centerY + 195 + (1 - t) * 30;
  const cardW = CANVAS_WIDTH - margin * 2;
  const cardH = 490;

  ctx.save();
  if (isNeon) {
    ctx.fillStyle = 'rgba(15, 23, 42, 0.96)';
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.45)';
    ctx.shadowColor = 'rgba(0, 229, 255, 0.2)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.1)';
  }

  ctx.lineWidth = 2;
  ctx.shadowBlur = 30;
  ctx.beginPath();
  ctx.roundRect(margin, cardY, cardW, cardH, 32);
  ctx.fill();
  ctx.stroke();
  clearShadow(ctx);

  const logoBoxW = cardW - 70;
  const logoBoxH = 220;
  const logoBoxX = margin + 35;
  const logoBoxY = cardY + 40;

  ctx.fillStyle = isNeon ? '#000000' : '#ffffff';
  ctx.strokeStyle = isNeon ? 'rgba(0, 229, 255, 0.25)' : 'rgba(15, 23, 42, 0.1)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(logoBoxX, logoBoxY, logoBoxW, logoBoxH, 24);
  ctx.fill();
  ctx.stroke();

  if (account.clientLogo) {
    try {
      const img = await loadImage(account.clientLogo);
      drawFittedImage(ctx, img, logoBoxX + 25, logoBoxY + 20, logoBoxW - 50, logoBoxH - 40);
    } catch {
      ctx.fillStyle = '#052638';
      ctx.font = '900 52px "Bricolage Grotesque", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(account.clientName, logoBoxX + logoBoxW / 2, logoBoxY + 125);
    }
  }

  ctx.fillStyle = isNeon ? '#ffffff' : '#090d16';
  ctx.font = `900 48px ${isEditorial ? '"Playfair Display"' : '"Plus Jakarta Sans"'}, sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText(account.clientName, CANVAS_WIDTH / 2, cardY + 320);

  ctx.fillStyle = isNeon ? '#cbd5e1' : '#475569';
  ctx.font = '700 30px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(account.clientIndustry, CANVAS_WIDTH / 2, cardY + 372);

  // Badge pill using contrastColor + accessible text contrast
  const badgeY = cardY + 440;
  if (isNeon) {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.95)';
    ctx.strokeStyle = contrastColor;
  } else if (isEditorial) {
    ctx.fillStyle = '#880c59';
    ctx.strokeStyle = '#880c59';
  } else {
    ctx.fillStyle = contrastColor;
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.16)';
  }

  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(CANVAS_WIDTH / 2 - 260, badgeY - 34, 520, 56, 18);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = isEditorial ? '#ffffff' : isNeon ? contrastColor : accentTextColor;
  ctx.font = '900 26px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(
    `Los ${account.milestones.length} Grandes Hitos del Año`,
    CANVAS_WIDTH / 2,
    badgeY + 3
  );
  ctx.restore();

  applySubtleTextShadow(ctx, isNeon);
  ctx.fillStyle = isNeon ? '#e2e8f0' : '#334155';
  ctx.font = '800 26px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Desliza para ver el impacto →', CANVAS_WIDTH / 2, CANVAS_HEIGHT - 90);
  clearShadow(ctx);
}

// Scene Milestone: Subtle Shadows, High Contrast, Configurable Font Size, Straight Badges
export async function renderMilestoneScene(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  milestone: PRMilestone,
  index: number,
  timeOffset: number = 0,
  slideProgress: number = 1
) {
  const theme = normalizeTheme(account.designTheme);
  const isNeon = theme === 'neon-billboard';
  const isEditorial = theme === 'editorial-press';
  const contrastColor = account.contrastColor || '#00f59b';
  const accentTextColor = getContrastTextColor(contrastColor);
  const scale = getFontScaleMultiplier(account.fontSize);

  const totalScenes = account.milestones.length + 2;
  drawThematicBackground(ctx, account, timeOffset, 1.1);
  await drawTopHeader(ctx, account, index + 1, totalScenes, slideProgress);

  const isDirectional = (account.animationStyle || 'directional') === 'directional';
  const margin = 80;
  const startY = 265;

  const t_tag = easeOutCubic(clamp(slideProgress * 3.5, 0, 1));
  const t_metric = easeOutCubic(clamp((slideProgress - 0.04) * 3.2, 0, 1));
  const t_label = easeOutCubic(clamp((slideProgress - 0.08) * 3.2, 0, 1));
  const t_head = easeOutCubic(clamp((slideProgress - 0.12) * 3.0, 0, 1));
  const t_img = easeOutCubic(clamp((slideProgress - 0.16) * 2.8, 0, 1));
  const t_desc = easeOutCubic(clamp((slideProgress - 0.2) * 2.8, 0, 1));

  ctx.save();

  // 1. Index Header + Straight Sticker Badge
  const tagX = isDirectional ? margin - (1 - t_tag) * 200 : margin;
  ctx.globalAlpha = t_tag;

  applySubtleTextShadow(ctx, isNeon);
  ctx.fillStyle = isNeon ? '#f9a8d4' : '#880c59';
  const indexFontFamily = isEditorial ? '"Playfair Display"' : '"Bricolage Grotesque"';
  ctx.font = `900 48px ${indexFontFamily}, sans-serif`;
  ctx.textAlign = 'left';
  ctx.fillText(`0${index + 1} / 0${account.milestones.length}`, tagX, startY);
  clearShadow(ctx);

  // Straight Sticker Badge on Right (NO rotation)
  const stickerText = (milestone.stickerBadge || 'HITO ESTRATÉGICO').toUpperCase();
  ctx.font = '900 24px "Plus Jakarta Sans", sans-serif';
  const stickerTextW = ctx.measureText(stickerText).width;
  const stickerBoxW = stickerTextW + 48;
  const stickerBoxH = 48;
  const stickerBoxX = CANVAS_WIDTH - margin - stickerBoxW;
  const stickerBoxY = startY - 38;

  ctx.save();
  if (isNeon) {
    ctx.fillStyle = 'rgba(255, 0, 127, 0.25)';
    ctx.strokeStyle = '#ff47a3';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
    ctx.shadowBlur = 12;
  } else if (isEditorial) {
    ctx.fillStyle = '#880c59';
    ctx.strokeStyle = '#880c59';
    ctx.lineWidth = 1;
  } else {
    ctx.fillStyle = contrastColor;
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.18)';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(15, 23, 42, 0.12)';
    ctx.shadowBlur = 10;
  }

  ctx.beginPath();
  ctx.roundRect(stickerBoxX, stickerBoxY, stickerBoxW, stickerBoxH, 24);
  ctx.fill();
  ctx.stroke();
  clearShadow(ctx);

  ctx.fillStyle = isNeon ? '#fbcfe8' : isEditorial ? '#ffffff' : accentTextColor;
  ctx.textAlign = 'center';
  ctx.fillText(stickerText, stickerBoxX + stickerBoxW / 2, stickerBoxY + 32);
  ctx.restore();

  // 2. CIFRA (Scaled by fontSize + Subtle Shadow + High Contrast)
  const metricFontPx = Math.round(160 * scale);
  const metricYOffset = isDirectional ? (1 - t_metric) * 90 : (1 - t_metric) * 40;
  const metricY = startY + 195 + metricYOffset;
  ctx.globalAlpha = t_metric;

  if (isNeon) {
    ctx.fillStyle = contrastColor;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.92)';
    ctx.shadowBlur = 24;
    ctx.shadowOffsetY = 4;
  } else {
    ctx.fillStyle = '#052638';
    applySubtleTextShadow(ctx, false, true);
  }

  const metricFontFamily = isEditorial ? '"Playfair Display"' : '"Bricolage Grotesque"';
  ctx.font = `900 ${metricFontPx}px ${metricFontFamily}, "Plus Jakarta Sans", sans-serif`;
  ctx.textAlign = 'left';
  ctx.fillText(milestone.metricValue, margin, metricY);
  clearShadow(ctx);

  // 3. ETIQUETA (Scaled + Shadow + Higher Contrast)
  const labelFontPx = Math.round(38 * scale);
  const labelXOffset = isDirectional ? (1 - t_label) * 160 : 0;
  ctx.globalAlpha = t_label;
  applySubtleTextShadow(ctx, isNeon);
  ctx.fillStyle = isNeon ? '#f9a8d4' : '#7a0a50';
  ctx.font = `900 ${labelFontPx}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(milestone.metricLabel.toUpperCase(), margin + labelXOffset, metricY + 68);
  clearShadow(ctx);

  // Divider line
  ctx.strokeStyle = isNeon ? 'rgba(255, 255, 255, 0.22)' : contrastColor;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(margin, metricY + 112);
  ctx.lineTo(CANVAS_WIDTH - margin, metricY + 112);
  ctx.stroke();

  // 4. TITULAR (Scaled + Subtle Text Shadow + Max Contrast Ink)
  const headlineFontPx = Math.round(62 * scale);
  const headlineLineHeight = Math.round(76 * scale);
  const headlineX = isDirectional ? margin - (1 - t_head) * 180 : margin;
  ctx.globalAlpha = t_head;
  applySubtleTextShadow(ctx, isNeon, true);
  ctx.fillStyle = isNeon ? '#ffffff' : '#090d16';
  const headlineFontFamily = isEditorial ? '"Playfair Display"' : '"Plus Jakarta Sans"';
  ctx.font = `900 ${headlineFontPx}px ${headlineFontFamily}, sans-serif`;
  const headlineText = isEditorial ? `“${milestone.headline}”` : milestone.headline;
  const headlineEndY = drawWrappedText(
    ctx,
    headlineText,
    headlineX,
    metricY + 188,
    CANVAS_WIDTH - margin * 2,
    headlineLineHeight
  );
  clearShadow(ctx);

  let contentCursorY = headlineEndY + 30;

  // 5. OPTIONAL REFERENCE IMAGE
  if (milestone.image) {
    const imgH = 335;
    const imgW = CANVAS_WIDTH - margin * 2;
    const imgY = contentCursorY + (isDirectional ? (1 - t_img) * 50 : 0);

    ctx.globalAlpha = t_img;
    try {
      const refImg = await loadImage(milestone.image);
      ctx.shadowColor = isNeon ? 'rgba(0, 229, 255, 0.25)' : 'rgba(15, 23, 42, 0.16)';
      ctx.shadowBlur = 20;
      drawCoverImageRounded(ctx, refImg, margin, imgY, imgW, imgH, 24);
      clearShadow(ctx);

      ctx.strokeStyle = isNeon ? 'rgba(0, 229, 255, 0.35)' : 'rgba(15, 23, 42, 0.14)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(margin, imgY, imgW, imgH, 24);
      ctx.stroke();
    } catch {
      // quiet fallback
    }

    contentCursorY = imgY + imgH + 30;
  }

  // 6. DESCRIPCIÓN (Scaled + High Contrast Backing Card + Subtle Shadow)
  const descFontPx = Math.round(36 * scale);
  const descLineHeight = Math.round(52 * scale);
  const descBoxY = contentCursorY + (isDirectional ? (1 - t_desc) * 45 : 0);
  const descBoxH = Math.max(180, Math.min(340, CANVAS_HEIGHT - descBoxY - 145));

  ctx.globalAlpha = t_desc;
  if (isNeon) {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.94)';
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.32)';
  } else if (isEditorial) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
    ctx.strokeStyle = 'rgba(180, 83, 9, 0.22)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';
  }

  ctx.lineWidth = 2;
  ctx.shadowColor = 'rgba(15, 23, 42, 0.1)';
  ctx.shadowBlur = 22;
  ctx.beginPath();
  ctx.roundRect(margin, descBoxY, CANVAS_WIDTH - margin * 2, descBoxH, 24);
  ctx.fill();
  ctx.stroke();
  clearShadow(ctx);

  if (isNeon) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetY = 1;
  }
  ctx.fillStyle = isNeon ? '#ffffff' : '#0f172a';
  ctx.font = `600 ${descFontPx}px "Plus Jakarta Sans", sans-serif`;
  drawWrappedText(
    ctx,
    milestone.description,
    margin + 45,
    descBoxY + 64,
    CANVAS_WIDTH - margin * 2 - 90,
    descLineHeight
  );
  clearShadow(ctx);

  // Footer: Transparent Standard Modum Logo
  ctx.globalAlpha = 0.95;
  try {
    const modumImg = await getModumLogoImage(isNeon ? 'dark' : 'light', 'standard');
    drawFittedImage(ctx, modumImg, CANVAS_WIDTH / 2 - 115, CANVAS_HEIGHT - 120, 230, 68, 'center');
  } catch {
    ctx.fillStyle = isNeon ? '#cbd5e1' : '#475569';
    ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('modum · impacto estratégico', CANVAS_WIDTH / 2, CANVAS_HEIGHT - 65);
  }
  ctx.restore();
}

// Scene Outro: Celebratory Modum 10 Años Closing (No Milestone Recap List)
export async function renderOutroScene(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  timeOffset: number = 0,
  slideProgress: number = 1
) {
  const theme = normalizeTheme(account.designTheme);
  const isNeon = theme === 'neon-billboard';
  const isEditorial = theme === 'editorial-press';
  const contrastColor = account.contrastColor || '#00f59b';
  const accentTextColor = getContrastTextColor(contrastColor);

  const totalScenes = account.milestones.length + 2;
  drawThematicBackground(ctx, account, timeOffset, 1.2);
  await drawTopHeader(ctx, account, totalScenes - 1, totalScenes, slideProgress);

  const t = easeOutCubic(clamp(slideProgress * 2.5, 0, 1));
  const margin = 80;
  const startY = 340;

  ctx.save();
  ctx.textAlign = 'center';

  // Top eyebrow & monumental headline
  applySubtleTextShadow(ctx, isNeon);
  ctx.globalAlpha = t;
  ctx.fillStyle = isNeon ? '#f9a8d4' : '#880c59';
  ctx.font = '900 32px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(`MISIÓN CUMPLIDA · ${account.year}`, CANVAS_WIDTH / 2, startY);

  applySubtleTextShadow(ctx, isNeon, true);
  ctx.fillStyle = isNeon ? '#ffffff' : '#090d16';
  const outroFont = isEditorial ? '"Playfair Display"' : '"Bricolage Grotesque"';
  ctx.font = `900 84px ${outroFont}, sans-serif`;
  ctx.fillText('IMPACTO IMPARABLE', CANVAS_WIDTH / 2, startY + 95);
  clearShadow(ctx);

  // Celebratory Hero Card: Modum 10 Años
  const cardY = startY + 170 + (1 - t) * 35;
  const cardW = CANVAS_WIDTH - margin * 2;
  const cardH = 1040;

  if (isNeon) {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.94)';
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.4)';
    ctx.shadowColor = 'rgba(0, 229, 255, 0.2)';
  } else if (isEditorial) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
    ctx.strokeStyle = 'rgba(180, 83, 9, 0.22)';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.1)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.1)';
  }

  ctx.lineWidth = 2.5;
  ctx.shadowBlur = 32;
  ctx.beginPath();
  ctx.roundRect(margin, cardY, cardW, cardH, 36);
  ctx.fill();
  ctx.stroke();
  clearShadow(ctx);

  // Special Edition Pill
  const badgeY = cardY + 95;
  if (isNeon) {
    ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
    ctx.strokeStyle = contrastColor;
  } else if (isEditorial) {
    ctx.fillStyle = '#880c59';
    ctx.strokeStyle = '#880c59';
  } else {
    ctx.fillStyle = contrastColor;
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.15)';
  }
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(CANVAS_WIDTH / 2 - 230, badgeY - 34, 460, 56, 28);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = isEditorial ? '#ffffff' : isNeon ? contrastColor : accentTextColor;
  ctx.font = '900 24px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('EDICIÓN ESPECIAL · 10 AÑOS', CANVAS_WIDTH / 2, badgeY + 3);

  // Large Celebratory Modum 10 Años Image
  try {
    const modum10Img = await getModumLogoImage(isNeon ? 'dark' : 'light', 'anniversary10');
    drawFittedImage(ctx, modum10Img, CANVAS_WIDTH / 2 - 330, cardY + 170, 660, 350, 'center');
  } catch {
    ctx.fillStyle = isNeon ? '#ffffff' : '#880c59';
    ctx.font = '900 72px "Bricolage Grotesque", sans-serif';
    ctx.fillText('10 AÑOS modum', CANVAS_WIDTH / 2, cardY + 360);
  }

  // Divider line
  ctx.strokeStyle = isNeon ? 'rgba(255, 255, 255, 0.14)' : 'rgba(15, 23, 42, 0.1)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(margin + 70, cardY + 575);
  ctx.lineTo(CANVAS_WIDTH - margin - 70, cardY + 575);
  ctx.stroke();

  // Client Partnership Lockup
  let messageStartY = cardY + 690;
  if (account.clientLogo) {
    try {
      const clientImg = await loadImage(account.clientLogo);
      ctx.fillStyle = isNeon ? '#cbd5e1' : '#64748b';
      ctx.font = '800 22px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('JUNTO A', CANVAS_WIDTH / 2, cardY + 640);

      const logoBoxW = 280;
      const logoBoxH = 96;
      const logoBoxX = CANVAS_WIDTH / 2 - logoBoxW / 2;
      const logoBoxY = cardY + 668;

      ctx.fillStyle = isNeon ? '#000000' : '#ffffff';
      ctx.strokeStyle = isNeon ? 'rgba(255,255,255,0.18)' : 'rgba(15, 23, 42, 0.1)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(logoBoxX, logoBoxY, logoBoxW, logoBoxH, 20);
      ctx.fill();
      ctx.stroke();

      drawFittedImage(ctx, clientImg, logoBoxX + 18, logoBoxY + 12, logoBoxW - 36, logoBoxH - 24);
      messageStartY = cardY + 840;
    } catch {
      // quiet
    }
  }

  ctx.fillStyle = isNeon ? '#ffffff' : '#090d16';
  ctx.font = '800 36px "Plus Jakarta Sans", sans-serif';
  drawWrappedText(
    ctx,
    'Gracias por construir un año extraordinario junto a nosotros.',
    CANVAS_WIDTH / 2,
    messageStartY,
    cardW - 110,
    50,
    'center'
  );

  ctx.fillStyle = isNeon ? '#f9a8d4' : '#880c59';
  ctx.font = '900 32px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(
    `¡Listos para superar la meta en ${parseInt(account.year, 10) + 1}!`,
    CANVAS_WIDTH / 2,
    cardY + 975
  );

  ctx.fillStyle = isNeon ? '#cbd5e1' : '#475569';
  ctx.font = '700 24px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('modum.com.co', CANVAS_WIDTH / 2, CANVAS_HEIGHT - 55);
  ctx.restore();
}

// Master slide renderer
export async function renderSlide(
  ctx: CanvasRenderingContext2D,
  account: ClientAccount,
  slideIndex: number,
  timeOffset: number = 0,
  slideProgress: number = 1
) {
  const milestoneCount = account.milestones.length;
  if (slideIndex === 0) {
    await renderIntroScene(ctx, account, timeOffset, slideProgress);
  } else if (slideIndex >= 1 && slideIndex <= milestoneCount) {
    await renderMilestoneScene(
      ctx,
      account,
      account.milestones[slideIndex - 1],
      slideIndex - 1,
      timeOffset,
      slideProgress
    );
  } else {
    await renderOutroScene(ctx, account, timeOffset, slideProgress);
  }
}

// Export single slide as PNG Data URL
export async function exportSlideAsPNG(
  account: ClientAccount,
  slideIndex: number
): Promise<string> {
  await Promise.all([
    ensureFontsLoaded(),
    getModumLogoImage('light', 'standard'),
    getModumLogoImage('dark', 'standard'),
    getModumLogoImage('light', 'anniversary10'),
    getModumLogoImage('dark', 'anniversary10')
  ]);
  const canvas = document.createElement('canvas');
  canvas.width = CANVAS_WIDTH;
  canvas.height = CANVAS_HEIGHT;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not get 2D canvas context');

  await renderSlide(ctx, account, slideIndex, 0, 1);
  return canvas.toDataURL('image/png');
}

// Find best supported MP4/video MIME type for MediaRecorder
export function getPreferredMimeType(): string {
  const mimeTypes = [
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4;codecs=avc1',
    'video/mp4;codecs=h264',
    'video/mp4',
    'video/webm;codecs=h264,opus',
    'video/webm;codecs=vp9,opus',
    'video/webm'
  ];

  for (const mime of mimeTypes) {
    if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(mime)) {
      return mime;
    }
  }
  return 'video/webm';
}

// Record Full 9:16 Vertical Video in MP4 Format
export async function recordFullWrappedVideo(
  account: ClientAccount,
  onProgress: (progress: number, message: string) => void,
  secondsPerSlide: number = 6.5
): Promise<{ blob: Blob; mimeType: string }> {
  onProgress(5, 'Cargando tipografías, logotipo modum y preparando lienzo HD...');
  await Promise.all([
    ensureFontsLoaded(),
    getModumLogoImage('light', 'standard'),
    getModumLogoImage('dark', 'standard'),
    getModumLogoImage('light', 'anniversary10'),
    getModumLogoImage('dark', 'anniversary10')
  ]);

  if (account.clientLogo) {
    try {
      await loadImage(account.clientLogo);
    } catch {
      // continue
    }
  }

  for (const m of account.milestones) {
    if (m.image) {
      try {
        await loadImage(m.image);
      } catch {
        // continue
      }
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = CANVAS_WIDTH;
  canvas.height = CANVAS_HEIGHT;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('Could not initialize canvas for video recording');

  onProgress(10, 'Iniciando sintetizador de audio y flujo de grabación MP4...');

  audioSynth.startBeat();
  const audioDestination = audioSynth.getAudioStreamDestination();

  const canvasStream = canvas.captureStream(30);
  const combinedStream = new MediaStream();

  canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));

  if (audioDestination && audioDestination.stream.getAudioTracks().length > 0) {
    audioDestination.stream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));
  }

  const chosenMimeType = getPreferredMimeType();

  const mediaRecorder = new MediaRecorder(combinedStream, {
    mimeType: chosenMimeType,
    videoBitsPerSecond: 10000000
  });

  const recordedChunks: Blob[] = [];
  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      recordedChunks.push(e.data);
    }
  };

  return new Promise(async (resolve, reject) => {
    mediaRecorder.onstop = () => {
      audioSynth.stopBeat();
      const outputMime = chosenMimeType.includes('mp4') ? 'video/mp4' : chosenMimeType;
      const blob = new Blob(recordedChunks, { type: outputMime });
      onProgress(100, '¡Video MP4 generado con éxito!');
      resolve({ blob, mimeType: outputMime });
    };

    mediaRecorder.onerror = (e) => {
      audioSynth.stopBeat();
      reject(e);
    };

    mediaRecorder.start(100);

    const totalSlides = account.milestones.length + 2;
    const fps = 30;
    const framesPerSlide = Math.floor(secondsPerSlide * fps);
    const totalFrames = totalSlides * framesPerSlide;
    let currentFrame = 0;

    const interval = 1000 / fps;

    const frameTimer = window.setInterval(async () => {
      currentFrame++;
      const currentSlide = Math.min(
        Math.floor(currentFrame / framesPerSlide),
        totalSlides - 1
      );

      const frameInSlide = currentFrame % framesPerSlide;
      const slideProgress = frameInSlide / framesPerSlide;
      const timeOffset = currentFrame * 0.03;

      if (frameInSlide === 1 && currentSlide > 0) {
        audioSynth.playWhoosh();
      }

      await renderSlide(ctx, account, currentSlide, timeOffset, slideProgress);

      const progressPercent = Math.min(95, Math.floor((currentFrame / totalFrames) * 88) + 10);
      const slideTitle =
        currentSlide === 0
          ? 'Introducción'
          : currentSlide === totalSlides - 1
          ? 'Cierre Anual'
          : `Hito 0${currentSlide}: ${account.milestones[currentSlide - 1]?.metricValue || ''}`;

      onProgress(
        progressPercent,
        `Renderizando animaciones de ${slideTitle} (${Math.floor(currentFrame / fps)}s / ${Math.floor(totalFrames / fps)}s)...`
      );

      if (currentFrame >= totalFrames) {
        clearInterval(frameTimer);
        onProgress(97, 'Codificando contenedor MP4 en alta definición...');
        window.setTimeout(() => {
          mediaRecorder.stop();
        }, 300);
      }
    }, interval);
  });
}
