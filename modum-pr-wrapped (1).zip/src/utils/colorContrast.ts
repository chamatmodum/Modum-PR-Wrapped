/**
 * Computes accessible high-contrast foreground color (#ffffff or #09090b)
 * for any arbitrary Hex background color chosen by the user.
 */
export function getContrastTextColor(hex: string): '#ffffff' | '#09090b' {
  const clean = (hex || '').replace('#', '').trim();
  let r = 0;
  let g = 245;
  let b = 155;

  if (clean.length === 3) {
    r = parseInt(clean[0] + clean[0], 16);
    g = parseInt(clean[1] + clean[1], 16);
    b = parseInt(clean[2] + clean[2], 16);
  } else if (clean.length === 6) {
    r = parseInt(clean.slice(0, 2), 16);
    g = parseInt(clean.slice(2, 4), 16);
    b = parseInt(clean.slice(4, 6), 16);
  }

  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) {
    return '#09090b';
  }

  // Relative perceptual luminance (ITU-R BT.709)
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.52 ? '#09090b' : '#ffffff';
}
