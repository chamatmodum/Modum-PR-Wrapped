import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FormEditor } from './components/FormEditor';
import { StoryViewer } from './components/StoryViewer';
import { ExportModal } from './components/ExportModal';
import { PresentationModal } from './components/PresentationModal';
import { ModumLogo } from './components/ModumLogo';
import { ClientAccount, DesignTheme } from './types';
import { CLIENT_PRESETS } from './data/presets';
import { Eye, RotateCcw, Smartphone, SlidersHorizontal } from 'lucide-react';

const STORAGE_KEY = 'modum_wrapped_account_data';
const VALID_THEMES: DesignTheme[] = ['kinetic-pop', 'editorial-press', 'neon-billboard'];

export default function App() {
  const [account, setAccount] = useState<ClientAccount>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as ClientAccount;
        if (!parsed.designTheme || !VALID_THEMES.includes(parsed.designTheme)) {
          parsed.designTheme = 'kinetic-pop';
        }
        return parsed;
      }
    } catch {
      // fallback
    }
    return CLIENT_PRESETS[0];
  });

  const [activeTab, setActiveTab] = useState<'editor' | 'viewer' | 'export'>('viewer');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isPresentationModalOpen, setIsPresentationModalOpen] = useState<boolean>(false);

  // Save to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(account));
    } catch {
      // quiet fail
    }
  }, [account]);

  const handleLoadPreset = (presetIndex: number) => {
    const selected = CLIENT_PRESETS[presetIndex];
    if (selected) {
      setAccount(selected);
    }
  };

  const handleResetToDefault = () => {
    if (window.confirm('¿Deseas restaurar la plantilla inicial de NuvoPay?')) {
      setAccount(CLIENT_PRESETS[0]);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col selection:bg-[#880c59] selection:text-white">
      {/* Top Bar Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenVideoExport={() => setIsExportModalOpen(true)}
        onLoadPreset={handleLoadPreset}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Sub-toolbar: Active Client Info & Workspace Mode Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div
              className="w-3.5 h-3.5 rounded-full ring-4 ring-slate-100 shadow-xs"
              style={{ backgroundColor: account.contrastColor }}
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">{account.clientName}</span>
                <span className="text-slate-300 text-xs">·</span>
                <span className="text-xs text-slate-500 font-medium">{account.clientIndustry}</span>
              </div>
              <p className="text-[11px] text-slate-400">
                wrapped {account.year} · {account.milestones.length} hitos configurados
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-slate-100 border border-slate-200/70 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('editor')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === 'editor'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Formulario</span>
              </button>

              <button
                onClick={() => setActiveTab('viewer')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === 'viewer'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Visor 9:16</span>
              </button>
            </div>

            <button
              onClick={handleResetToDefault}
              title="Restablecer a valores iniciales"
              className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200/70 rounded-xl transition-colors text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dynamic View Sections */}
        {activeTab === 'editor' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-8">
              <FormEditor
                account={account}
                onChange={setAccount}
                onPreview={() => setActiveTab('viewer')}
                onLoadPreset={handleLoadPreset}
              />
            </div>

            {/* Sticky Live Mini Preview on desktop */}
            <div className="hidden lg:block lg:col-span-4 sticky top-20 space-y-4">
              <div className="bg-white border border-slate-200/90 rounded-2xl p-4 space-y-3 shadow-xs">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800">Vista Previa Luminosa</span>
                  <button
                    onClick={() => setActiveTab('viewer')}
                    className="text-[#880c59] font-bold hover:underline flex items-center gap-1"
                  >
                    <Eye className="w-3 h-3" />
                    <span>Abrir Visor</span>
                  </button>
                </div>
                <div className="scale-90 origin-top">
                  <StoryViewer
                    account={account}
                    onOpenVideoExport={() => setIsExportModalOpen(true)}
                    onOpenFullscreen={() => setIsPresentationModalOpen(true)}
                    onUpdateTheme={(theme) => setAccount((prev) => ({ ...prev, designTheme: theme }))}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'viewer' && (
          <div className="flex flex-col items-center justify-center">
            <StoryViewer
              account={account}
              onOpenVideoExport={() => setIsExportModalOpen(true)}
              onOpenFullscreen={() => setIsPresentationModalOpen(true)}
              onUpdateTheme={(theme) => setAccount((prev) => ({ ...prev, designTheme: theme }))}
            />
          </div>
        )}

        {activeTab === 'export' && (
          <div className="max-w-2xl mx-auto">
            <ExportModal
              isOpen={true}
              onClose={() => setActiveTab('viewer')}
              account={account}
            />
          </div>
        )}
      </main>

      {/* Global Modals */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        account={account}
      />

      <PresentationModal
        isOpen={isPresentationModalOpen}
        onClose={() => setIsPresentationModalOpen(false)}
        account={account}
      />

      {/* Footer with clean light aesthetic */}
      <footer className="border-t border-slate-200/80 bg-white py-5 px-6 text-center text-xs text-slate-500 mt-auto">
        <div className="flex items-center justify-center gap-3 font-medium">
          <ModumLogo variant="light" className="h-5 w-auto object-contain" />
          <span>·</span>
          <span>creación audiovisual</span>
          <span>·</span>
          <span>modum.com.co</span>
        </div>
      </footer>
    </div>
  );
}
