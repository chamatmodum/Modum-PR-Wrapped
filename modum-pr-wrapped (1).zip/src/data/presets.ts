import { ClientAccount } from '../types';

export const SAMPLE_LOGOS = {
  fintech: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 80" width="280" height="80"><rect width="280" height="80" rx="16" fill="%23ffffff"/><path d="M36 24 L58 56 L24 56 Z" fill="%2300c875"/><circle cx="60" cy="30" r="10" fill="%230a3850"/><text x="88" y="52" fill="%230a3850" font-family="sans-serif" font-weight="900" font-size="28" letter-spacing="-1">NUVOPAY</text></svg>`,
  retail: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 80" width="280" height="80"><rect width="280" height="80" rx="16" fill="%23ffffff"/><circle cx="44" cy="40" r="18" fill="%23f59e0b"/><path d="M36 40 Q44 26 52 40 Q44 54 36 40" fill="%23ffffff"/><text x="76" y="50" fill="%230a3850" font-family="sans-serif" font-weight="800" font-size="24" letter-spacing="-0.5">TERRAVERDE</text></svg>`,
  biotech: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 80" width="280" height="80"><rect width="280" height="80" rx="16" fill="%23ffffff"/><circle cx="42" cy="40" r="16" stroke="%230284c7" stroke-width="5" fill="none"/><circle cx="42" cy="40" r="7" fill="%230284c7"/><text x="74" y="50" fill="%230a3850" font-family="sans-serif" font-weight="900" font-size="28" letter-spacing="-1">AURA</text></svg>`,
  modumLogo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 50" width="180" height="50"><text x="10" y="35" fill="%23ffffff" font-family="sans-serif" font-weight="900" font-size="32" letter-spacing="-1">MODUM</text><circle cx="152" cy="24" r="6" fill="%23880c59"/></svg>`
};

export const SAMPLE_MILESTONE_IMAGES = {
  pressTier1: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360"><rect width="600" height="360" rx="20" fill="%230a3850"/><rect x="20" y="20" width="560" height="320" rx="14" fill="%23ffffff" fill-opacity="0.08"/><text x="50" y="80" fill="%2300f59b" font-family="sans-serif" font-weight="900" font-size="28" letter-spacing="3">FORBES · PORTADA</text><rect x="50" y="110" width="340" height="12" rx="6" fill="%23ffffff" fill-opacity="0.9"/><rect x="50" y="135" width="480" height="8" rx="4" fill="%23ffffff" fill-opacity="0.4"/><rect x="50" y="155" width="420" height="8" rx="4" fill="%23ffffff" fill-opacity="0.4"/><rect x="50" y="175" width="360" height="8" rx="4" fill="%23ffffff" fill-opacity="0.4"/><circle cx="480" cy="240" r="50" fill="%23880c59" fill-opacity="0.6"/><path d="M465 240 L495 240 M480 225 L480 255" stroke="%23ffffff" stroke-width="4" stroke-linecap="round"/><text x="50" y="300" fill="%23ffffff" font-family="sans-serif" font-weight="700" font-size="16">REPORTE ESPECIAL DE IMPACTO</text></svg>`,
  keynoteEvent: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360"><rect width="600" height="360" rx="20" fill="%231e1b4b"/><circle cx="300" cy="180" r="140" fill="%23880c59" fill-opacity="0.3"/><circle cx="300" cy="140" r="45" fill="%23ffffff" fill-opacity="0.9"/><path d="M210 260 C210 200, 390 200, 390 260 Z" fill="%23ffffff" fill-opacity="0.85"/><text x="300" y="315" fill="%2300f59b" font-family="sans-serif" font-weight="900" font-size="22" text-anchor="middle" letter-spacing="2">KEYNOTE · WEB SUMMIT</text></svg>`,
  bcorpCert: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360"><rect width="600" height="360" rx="20" fill="%23064e3b"/><circle cx="300" cy="160" r="75" stroke="%23ffc837" stroke-width="8" fill="none"/><text x="300" y="185" fill="%23ffc837" font-family="sans-serif" font-weight="900" font-size="70" text-anchor="middle">B</text><text x="300" y="290" fill="%23ffffff" font-family="sans-serif" font-weight="800" font-size="22" text-anchor="middle" letter-spacing="1">CERTIFIED B CORP 2026</text></svg>`
};

export const COLOR_SWATCHES = [
  { name: 'Lima Eléctrico (Alto Contraste)', hex: '#00f59b', text: '#052e16' },
  { name: 'Cyan Neón', hex: '#00e5ff', text: '#083344' },
  { name: 'Amarillo Solar', hex: '#ffc837', text: '#451a03' },
  { name: 'Coral Neón', hex: '#ff5e62', text: '#450a0a' },
  { name: 'Magenta Vibrante', hex: '#ff40ac', text: '#380023' },
  { name: 'Blanco Puro', hex: '#ffffff', text: '#09090b' },
];

export const CLIENT_PRESETS: ClientAccount[] = [
  {
    clientName: 'NuvoPay Technologies',
    clientIndustry: 'FinTech & Pagos Digitales',
    clientLogo: SAMPLE_LOGOS.fintech,
    contrastColor: '#00f59b',
    year: '2026',
    accountLead: 'Equipo Fintech Modum',
    animationStyle: 'directional',
    designTheme: 'kinetic-pop',
    milestones: [
      {
        id: 1,
        headline: 'Apertura de Portada en Forbes & Bloomberg Línea',
        metricValue: '14.5M',
        metricLabel: 'Lectores e impactos calificados',
        stickerBadge: 'PORTADA DEL AÑO',
        description: 'Posicionamiento del CEO de NuvoPay como referente regional en inclusión financiera y billeteras digitales sin comisiones ocultas.',
        image: SAMPLE_MILESTONE_IMAGES.pressTier1
      },
      {
        id: 2,
        headline: 'Giro Narrativo en Actualización Regulatoria',
        metricValue: '96%',
        metricLabel: 'Sentimiento favorable de stakeholders',
        stickerBadge: 'BLINDAJE REPUTACIONAL',
        description: 'Manejo proactivo de comunicación preventiva ante la nueva ley bancaria, protegiendo la reputación y blindando la confianza de los usuarios.'
      },
      {
        id: 3,
        headline: 'Fenómeno Viral: Lanzamiento #PagaSinFricción',
        metricValue: '+450K',
        metricLabel: 'Menciones orgánicas en 48 horas',
        stickerBadge: 'TRENDING #1',
        description: 'Estrategia multiplataforma combinando prensa tech y tendencias en redes con 0 inversión en pauta de queja.'
      },
      {
        id: 4,
        headline: 'Keynote Speaker en Escenario Principal de Web Summit',
        metricValue: '8',
        metricLabel: 'Entrevistas exclusivas 1-on-1 gestionadas',
        stickerBadge: 'IMPACTO GLOBAL',
        description: 'La dirección ejecutiva compartió escenario con líderes globales, consolidando la alianza para la ronda de expansión internacional.',
        image: SAMPLE_MILESTONE_IMAGES.keynoteEvent
      },
      {
        id: 5,
        headline: 'Récord Histórico de Valor PR Acumulado',
        metricValue: '$4.8M',
        metricLabel: 'Equivalente Publicitario (EAV) certificado',
        stickerBadge: 'RÉCORD HISTÓRICO',
        description: 'Más de 310 publicaciones orgánicas en el año. NuvoPay se consolidó como la fintech con mayor Share of Voice del país.'
      }
    ]
  },
  {
    clientName: 'TerraVerde Organics',
    clientIndustry: 'Retail Sostenible & Bienestar',
    clientLogo: SAMPLE_LOGOS.retail,
    contrastColor: '#ffc837',
    year: '2026',
    accountLead: 'Equipo Sostenibilidad Modum',
    animationStyle: 'directional',
    designTheme: 'editorial-press',
    milestones: [
      {
        id: 1,
        headline: 'Anuncio Mundial de la Certificación B Corp',
        metricValue: '18',
        metricLabel: 'Países con cobertura simultánea',
        stickerBadge: 'HITO B-CORP',
        description: 'Despliegue internacional destacando el modelo de trazabilidad regenerativa y comercio justo.',
        image: SAMPLE_MILESTONE_IMAGES.bcorpCert
      },
      {
        id: 2,
        headline: 'Movimiento Ciudadano #MenosPlásticoMásVida',
        metricValue: '9.4M',
        metricLabel: 'Reproducciones orgánicas',
        stickerBadge: 'VIRAL VERDE',
        description: 'Reto viral de desintoxicación de empaques que inspiró a más de 40 empresas del sector retail.'
      },
      {
        id: 3,
        headline: 'Alianza Pública con el Ministerio de Ambiente',
        metricValue: '100%',
        metricLabel: 'Respaldo institucional sin fricción',
        stickerBadge: 'ACUERDO PAÍS',
        description: 'Firma de acuerdo para la reforestación de cuencas hídricas con presencia ministerial y repercusión nacional.'
      },
      {
        id: 4,
        headline: 'Dominio Absoluto en Revistas de Tendencia',
        metricValue: '+70',
        metricLabel: 'Reportajes y notas a página completa',
        stickerBadge: 'PRENSA DE ÉLITE',
        description: 'Apariciones destacadas en publicaciones de gastronomía, diseño y vida saludable.'
      }
    ]
  },
  {
    clientName: 'Aura Health & Biotech',
    clientIndustry: 'Ciencias de la Vida & HealthTech',
    clientLogo: SAMPLE_LOGOS.biotech,
    contrastColor: '#00e5ff',
    year: '2026',
    accountLead: 'Equipo Biotech Modum',
    animationStyle: 'zoom',
    designTheme: 'neon-billboard',
    milestones: [
      {
        id: 1,
        headline: 'Ensayo Clínico Destacado en The Lancet',
        metricValue: 'Top 1%',
        metricLabel: 'Impact Factor en revistas científicas',
        stickerBadge: 'CIENCIA DE PUNTA',
        description: 'Traducción de lenguaje biomédico complejo a titulares de alto impacto en medios masivos y especializados.'
      },
      {
        id: 2,
        headline: 'Cobertura Exclusiva de Serie B por $30M USD',
        metricValue: '$30M',
        metricLabel: 'Capital levantado comunicado con éxito',
        stickerBadge: 'INVERSIÓN GLOBAL',
        description: 'Primicia en TechCrunch y expansión mediática simultánea en fondos de inversión globales.'
      },
      {
        id: 3,
        headline: 'Iniciativa de Detección Temprana #TuSaludPrimero',
        metricValue: '1.2M',
        metricLabel: 'Chequeos preventivos impulsados por PR',
        stickerBadge: 'IMPACTO SOCIAL',
        description: 'Campaña pedagógica que desmitificó diagnósticos genéticos y llevó telemedicina a comunidades remotas.'
      }
    ]
  }
];
