# Modum PR Wrapped — Generador de Video y Animaciones Verticales para Hitos de Clientes

Plataforma interactiva para que los equipos de cuentas de la agencia **Modum** generen un resumen animado de relaciones públicas estilo **Spotify Wrapped** en formato vertical 9:16, listo para redes sociales (Instagram Stories, TikTok, LinkedIn) y presentaciones ejecutivas a clientes.

---

## Decisiones Confirmadas del Usuario

> [!IMPORTANT]
> - **Paleta de Identidad Modum**: `#880c59` (Magenta/Berry Profundo de Modum), `#0a3850` (Azul Océano Pizarra), `#6c7072` (Grafito Frío y Elegante).
> - **Formatos de Exportación Dual**: Exportación de Video Vertical (.webm / .mp4 compatible) con transiciones dinámicas y audio rítmico, más visor de Stories navegables e interactivo con descarga individual o en lote de diapositivas en alta resolución (1080x1920).
> - **Estilo de Narrativa Visual**: Tipografía cinética enérgica al estilo Spotify Wrapped, contadores numéricos animados de impacto/KPIs, fondos en gradientes fluidos que combinan la paleta Modum con el color de contraste del cliente, e integración prominente del logo del cliente.

---

## 1. Visión General y Concepto

La plataforma permite a cualquier ejecutivo o equipo de cuenta en Modum crear en menos de 3 minutos una pieza audiovisual y de contenido de alto impacto para celebrar el fin de año o cierre de ciclo de PR con sus clientes.

### Audiencia y Casos de Uso
- **Equipos de Cuentas y PR Managers de Modum**: Carga rápida de los 5 grandes momentos de comunicación estratégica del año de sus clientes.
- **Clientes de Modum**: Reciben un formato fresco, compartible y vanguardista (adiós a los reportes PDF aburridos de 40 páginas) que pueden postear en redes o mostrar a sus juntas directivas.
- **Redes Sociales de Modum y Clientes**: Formato nativo vertical 9:16 optimizado para Instagram Stories, Reels, TikTok y carruseles de LinkedIn.

---

## 2. Experiencia de Usuario y Diseño Visual

### A. Flujo de Trabajo (3 Fases Claras)
1. **Configuración de Cuenta & Marca**:
   - Nombre del cliente e industria.
   - Carga de Logo del cliente (soporte drag & drop PNG/SVG/JPG con vista previa inmediata y opciones de logos de prueba preconfigurados).
   - Selector del Color de Contraste del Cliente (con selector HEX y sugerencias armónicas que contrastan con los tonos `#880c59` y `#0a3850` de Modum: Lima Eléctrico, Coral Neón, Oro Cálido, Turquesa).
   - Año de gestión (por defecto 2026).
2. **Diligenciamiento de los 5 Hitos Clave**:
   - Formulario estructurado, amigable e intuitivo con 5 tarjetas guiadas:
     - **Hito 1: Marquee Headline / Gran Impacto Mediático** (Titular en medio Tier-1, medio, alcance estimado).
     - **Hito 2: Gestión Estratégica / Transformación de Reputación** (Reto superado, % favorabilidad / sentimiento positivo).
     - **Hito 3: Campaña Viral / Alcance Multicanal** (Hashtag o nombre de campaña, interacciones / trending topic).
     - **Hito 4: Liderazgo de Opinión / Vocería Ejecutiva** (Columna, entrevista destacada, evento o premio de industria).
     - **Hito 5: El Gran Cierre / Valor PR Acumulado** (Total impactos en medios, equivalencia publicitaria o ROI cualitativo, mensaje de cierre de Modum).
   - Botón de carga con 1-click de plantillas de ejemplo ("Fintech Innovadora", "Retail Sostenible", "Empresa de Tecnología B2B") para probar de inmediato.
3. **Estudio de Reproducción & Exportación (El Wrapped Engine)**:
   - **Visor Vertical 9:16 Interactivo**:
     - Barras de progreso superiores tipo Instagram Stories (con pausa al presionar / clic para avanzar o retroceder).
     - Animaciones cinéticas con Motion y Canvas: tipografía gigante que entra con fuerza, números que suben progresivamente (0 a 1.2M), partículas y ondas sutiles de fondo.
     - Música rítmica generada proceduralmente con Web Audio API (un beat synth moderno estilo Wrapped sin depender de URLs externas que puedan fallar) con interruptor de mute.
   - **Herramientas de Exportación**:
     - Grabador en tiempo real de video vertical (9:16 a 1080x1920) utilizando `MediaRecorder` y Canvas stream con sincronización de audio.
     - Descarga de paquete de imágenes de Stories en alta resolución (PNG).
     - Modo presentación en pantalla completa para juntas con clientes.

### B. Sistema Tipográfico y Estético
- **Dirección Estética**: Neo-editorial kinetic minimalista. Fondo profundo en `#0a3850` y `#880c59`, acentos nítidos y vibrantes con el color del cliente, y gris soporte `#6c7072` para balance.
- **Tipografías**:
  - Títulos y Números Cinéticos: `Plus Jakarta Sans` y `Bricolage Grotesque` en peso ultra-bold (800) con tracking ajustado.
  - Textos de lectura y citas: `DM Sans` / `Plus Jakarta Sans` para máxima legibilidad.
  - Cifras y métricas: `tabular-nums` con mono-espaciado para contadores numéricos fluidos.
- **Tratamiento de Metadatos**: Cumplimiento estricto anti-slop; sin píldoras estáticas genéricas, uso de separadores tipográficos limpios (`·` o `/`) y jerarquía espacial limpia.

---

## 3. Arquitectura Técnica y Estrategia de Datos

### Diagrama de Componentes y Flujo

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MODUM PR WRAPPED STUDIO                         │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │
         ┌───────────────────────────┴───────────────────────────┐
         ▼                                                       ▼
┌─────────────────────────────────┐             ┌───────────────────────────────────┐
│     Formulario de Gestión PR    │             │   Canvas & Story Engine (9:16)    │
│  - Logo & Color Contraste       │             │  - Intro Escena: "Modum Wrapped"  │
│  - Info Cliente y Año           │ ──────────► │  - 5 Escenas Cinéticas de Hitos   │
│  - 5 Hitos con Métricas & Citas │   Estado    │  - Outro Escena: Resumen & Sello  │
│  - Presets 1-Click (Fintech,    │  Reactivo   │  - Contadores de Números en Vivo  │
│    Retail, B2B Tech)            │             │  - Efectos de Gradiente Modum     │
└─────────────────────────────────┘             └─────────────────┬─────────────────┘
                                                                  │
                                                ┌─────────────────┴─────────────────┐
                                                ▼                                   ▼
                                ┌───────────────────────────────┐   ┌───────────────────────────────┐
                                │    Web Audio Synth Engine     │   │     Exportador Multimedia     │
                                │  - Beat Synth Loop Procedural │   │  - Video MP4/WebM (1080x1920) │
                                │  - SFX en transiciones        │   │  - Diapositivas PNG HD 9:16   │
                                │  - Control de volumen / mute  │   │  - Modo Presentación Fullscreen│
                                └───────────────────────────────┘   └───────────────────────────────┘
```

### Modelo de Datos Principal
```typescript
interface PRMilestone {
  id: number;
  category: string; // ej: "Impacto en Medios", "Manejo de Crisis", "Campaña Viral", "Liderazgo", "Cierre Anual"
  headline: string; // Titular de impacto
  metricValue: string; // ej: "+240%", "1.8M", "Top 1", "$3.5M"
  metricLabel: string; // ej: "Audiencia alcanzada en prensa", "Sentimiento positivo"
  description: string; // Resumen digerible del hito
  quoteOrSource?: string; // Medio / Vocero / Fuente
}

interface ClientAccount {
  clientName: string;
  year: string;
  clientLogo: string; // Data URL o SVG
  contrastColor: string; // Hexadecimal seleccionado
  tagline: string;
  milestones: [PRMilestone, PRMilestone, PRMilestone, PRMilestone, PRMilestone];
}
```

### Estrategia de Exportación de Video
1. **Renderizado de Video**: Se dibuja cada frame del Wrapped en un `<canvas>` interno a resolución 1080×1920 (9:16).
2. **Audio Procedural**: Se conecta el nodo de audio del sintetizador a un `MediaStreamDestinationNode`.
3. **Grabación**: `canvas.captureStream(60)` combinado con la pista de audio a través de la API estándar del navegador `MediaRecorder` (`video/webm;codecs=vp9` / `video/mp4`).
4. **Descarga Directa**: Generación de Blob y descarga automática con nombre limpio (ej: `Modum_Wrapped_2026_Cliente.webm`).

---

## 4. Pasos de Ejecución

1. **Configuración de Metadatos & SEO**:
   - Actualizar `metadata.json` e `index.html` con títulos, descripciones y branding oficial de Modum PR Agency.
2. **Motor de Datos & Presets de Relaciones Públicas**:
   - Tipos de datos, validadores y plantillas predeterminadas de clientes para pruebas inmediatas.
3. **Formulario Fácil de Cuentas Modum**:
   - Selector de cliente, selector de contrastes inteligentes que armonizan con `#880c59` y `#0a3850`, cargador de logo y editor secuencial de los 5 hitos.
4. **Reproductor y Escenas Animadas Spotify Wrapped (9:16)**:
   - Diseño cinético con Motion: Tipografías fluidas, contadores numéricos acelerados, barras de navegación de historias, logos fusionados (Modum + Cliente).
5. **Motor de Sonido & Grabador de Video**:
   - Generador de audio procedural Web Audio API y exportador de video HD con soporte para descarga de diapositivas individuales o completas.
6. **Compilación & Verificación**:
   - Chequeo de linter, compilación limpia con `compile_applet` y verificación de todos los flujos de interacción.
